# 文书库外起草与扩展入库

## 先出文书

235份基础库没有直接对应文书时：

先检查扩展文书库。已经存在X001等扩展能力卡即属于命中，不得再次联网搜索，也不得因模板检索延迟第一份正文。

1. 从用户原话提取“主体＋管理对象＋核心义务＋使用时点＋交付形式”关键词。
2. 首轮不联网、不先查法规，也不比较多个外部模板；直接选用最接近的同类合同、协议、制度、通知、表单或申请书结构。
3. 立即生成完整文书；未知事实用占位符，用户特别要求的高风险条款保留并在文后提示风险及替代写法。
4. 只有用户明确要求精确条文、最新规则、来源链接或二次优化时，才检索同类范文和法规，并据此修订已经交付的首稿。

## 扩展文书卡

文书生成后创建扩展卡，字段至少包括：

```yaml
extension_id: X001
title: 文书标题
keywords: [关键词]
scenario: 适用场景
document_type: agreement|notice|record|policy|form|other
required_modules: [核心模块]
source_summary: 使用过的模板类型或公开来源
risk_notes: [主要风险]
created_at: YYYY-MM-DD
review_status: generated_pending_review
```

扩展卡不得阻断首轮正文。平台环境不可写时，在回答末尾输出“待入库扩展卡”，供后续统一回收；不得把临时生成卡直接视为正式X编号。

正式入库在项目根目录执行：先按`extensions/新增文书入库及版本管理规范.md`查重并分配连续X编号，再复制`extensions/_template`形成独立入库包。运行`tools/extension_library_compiler.py check`校验；只有人工批准后才运行`build --apply-core`。编译器统一生成扩展目录、能力卡、路由、正文结构和测试注册表，不再为每份新增文书分别修改多处Python映射。

扩展卡进入Skill或公共发布库前仍须完成编号、母稿、审核状态和回归测试；Skill启用与公开发布是两个独立状态。
