# 核心运行契约 V1.9

四个平台调用同一入口：`scripts/skill_runtime.py INPUT_JSON OUTPUT_JSON`。

## 问诊路由

```json
{"operation":"intake","query":"员工入职三个月没签合同，现在准备补签，有什么风险？"}
```

明确文书需求返回`direct`且不在成稿前追问；一般咨询可返回最多3个简单问题。目录数量分为235份基础文书及扩展文书，并返回候选文书能力卡摘要。

`intake`同时返回`extracted_guard_facts`、`fact_extraction_records`和`preliminary_legal_guard_findings`。仅提取用户明确表达的事实，每条记录保留原文片段和命中文书；不确定问法不作不利推定。

## 多轮案件状态

```json
{"operation":"dialogue","turn":{"case_id":"C001","message":"公司80人，准备裁员10人。","state":null}}
```

平台在下一轮把返回的`result.state`原样放入新的`turn.state`。核心累计结构化事实、来源、候选文书、已确认前置条件和证据，不保存完整聊天文本。自动提取事实前后冲突时移出可用于成稿的事实集，并优先提出确认问题；用户明确使用“更正、改为、以此为准、经核实”等表达，或者平台通过`fact_updates`提交人工确认值时，更新该事实并清除冲突。

`intake`和`dialogue`返回`audience_profile`，包含`level`、`inferred_identity`、`response_style`、`question_limit`和`complexity_signals`。该对象用于调整表达难度和职业倾向，不展示内部层级标签，不改变文书主体和法律风险结论。

`dialogue`只有在第3轮以后、进阶或专业层、复杂信号不少于2项、已经具备可成稿结果且此前未显示时，才返回非空`consultation_prompt`；状态同时将`consultation_prompt_shown`设为真。

## 错误返回

命令行入口发生可识别错误时仍写出JSON，格式为：

```json
{
  "runtime_version": "1.9.2",
  "ok": false,
  "error": {
    "code": "missing_file_or_catalog",
    "message": "未找到235份文书知识目录。",
    "user_action": "请重新解压完整发布包，确认SKILL.md同级存在core、tools、scripts和references目录。",
    "retryable": false
  }
}
```

适配层先展示`user_action`，技术错误详情只用于日志；不得向普通用户显示绝对本地路径、堆栈、密钥或内部文件内容。

明确文书需求时，`dialogue`自动选定首份主文书并调用通用重构编排器。缺失事实或发生冲突时使用占位符，仍返回`draft_ready_with_review`且允许出稿；每轮问题不超过3个，默认只保留1个后置优化问题。

## 能力卡查询

```json
{"operation":"capability","document_ids":["F58","R68"]}
```

一次查询1至10份文书，返回触发事实、必需字段、模块、前置程序、证据、停止节点、风险级别、校准状态和候选关联文书。

## 动态重构

```json
{"operation":"reconstruct","scenario":{"case_id":"..."}}
```

`scenario` 必须符合项目内重构模型。返回状态、停止或补问事项、文书链、生成文书和一致性检查。

## 通用动态重构编排

```json
{"operation":"compose","case":{"case_id":"C001","objective":"起草竞业限制协议","selected_document_ids":["R42"],"facts":{}}}
```

`compose`适用于235份基础能力卡和扩展能力卡。它始终为已经选定的文书返回逐份`drafting_briefs`；缺失字段写入占位符，停止节点和证据缺口转为后置风险、替代条款和审校要求。

## 完整正文生成

```json
{"operation":"draft","case":{"case_id":"C001","objective":"起草竞业限制协议","selected_document_ids":["R42"],"facts":{}}}
```

`draft`先执行与`compose`相同的事实、证据和停止节点检查，并对已选定文书直接返回完整正文。代表文书使用专项结构，其他文书使用与文书功能相匹配的通用协议、通知、记录、制度或诉讼结构；缺失值使用`【请填写】`或`【请选择】`。

`compose`和`draft`还会对代表文书执行反向法律情景检查，并返回`legal_guard_findings`。这些结论不再清空正文，而用于风险提示、替代方案和审校；规则只由明确结构化事实触发，不从字段缺失推定违法。

`compose`和`draft`可在`case.user_query`中接收用户原话，自动提取风险事实。`case.facts`中的人工确认值优先于自动提取值；输出保留`extracted_guard_facts`和`fact_extraction_records`供平台解释和复核。

## 成稿与文件交付

```json
{"operation":"deliver","delivery":{"state":{"case_id":"C001","selected_document_ids":["R8"]},"formats":["docx","markdown","json"]}}
```

`state`必须直接使用`dialogue`返回值。`deliver`重新执行成稿门槛和自动审校；只有`status=delivery_ready`时才返回文件。DOCX内容使用base64，Markdown和JSON使用UTF-8，并随附字节数及SHA-256。详细字段及零文件门槛见`delivery-contract.md`。

适配层只能转换平台输入输出，不得更改候选检索、追问上限、证据状态、停止节点或动态重构结果。
