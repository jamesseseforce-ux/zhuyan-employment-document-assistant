from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CandidateDocument(StrictModel):
    document_id: str
    title: str
    stage: str
    score: int
    reason: str


class IntakeResult(StrictModel):
    mode: Literal["direct", "targeted", "fallback"]
    clarity: Literal["clear", "partial", "unclear"]
    matched_intent: str | None
    matched_keywords: list[str]
    candidate_documents: list[CandidateDocument]
    questions: list[str]
    next_action: str
    route_adjustment_notice: str | None = None


INTENT_PACKS = [
    {
        "intent": "self_media_account",
        "keywords": ("自媒体账号", "抖音账号", "小红书账号", "视频号", "账号归属", "手机号注册", "工作手机号", "内容归属"),
        "documents": ("X001",),
        "questions": (
            "如需补全，请告诉我账号平台、注册手机号由谁持有，以及员工离职时如何交接。",
        ),
    },
    {
        "intent": "resignation_pressure",
        "keywords": ("劝退", "诱导辞职", "威胁辞职", "逼迫辞职", "个人辞职申请", "主动辞职", "被迫辞职"),
        "documents": ("R128", "R129", "R131", "R132", "F55"),
        "questions": (
            "辞职申请由谁起草，签署前后企业具体说过或做过什么，是否有录音、聊天或见证人？",
            "签署前是否已停权、停工、停薪或提出补偿，员工签署后是否继续上班？",
            "企业现在需要设计协商退出方案，还是应对员工主张被迫辞职或违法解除？",
        ),
    },
    {
        "intent": "disguised_labor_relation",
        "keywords": ("劳务合同", "事实劳动关系", "确认劳动关系", "实则劳动关系", "假劳务", "合作协议用工"),
        "documents": ("R23", "R24", "R19", "R66", "R8"),
        "questions": (
            "谁决定工作时间、地点、方法和奖惩，个人能否拒单、定价或找人替代？",
            "报酬按月还是按成果支付，是否存在考勤、工牌、企业账号、工资表和社保记录？",
            "企业需要继续用工、整改历史合同，还是应对确认劳动关系争议？",
        ),
    },
    {
        "intent": "access_lockout",
        "keywords": ("关闭门禁", "门禁权限", "关闭账号", "系统账号", "取消工位", "不让上班", "不让进公司"),
        "documents": ("R99", "F32", "R133", "R143", "F63"),
        "questions": (
            "门禁、账号和工位分别何时处理，员工当时收到什么书面工作安排？",
            "停权后是否继续支付工资、提供替代办公条件并发出可实际履行的返岗通知？",
            "员工随后何时缺勤、辞职或发解除通知，目前是否已经进入仲裁？",
        ),
    },
    {
        "intent": "discipline_transfer_or_dismissal",
        "keywords": ("不服从管理", "轻微违规", "无证据", "证据不足", "飞单", "泄密", "挖角", "业绩不好", "补充证据", "补造证据", "单方降薪"),
        "documents": ("F31", "F34", "F36", "F28", "F29"),
        "questions": (
            "企业拟采取警告、调岗降薪还是解除，准备固定的具体事实和法律路径是什么？",
            "解除或处理当时已经存在的原始证据、制度、公示、民主程序和申辩材料有哪些？",
            "该行为造成什么具体后果，员工仍在岗还是已进入仲裁？",
        ),
    },
    {
        "intent": "restructuring_or_layoff",
        "keywords": ("经营下降", "经营困难", "客观情况发生重大变化", "经济性裁员", "经济裁员", "批量裁员", "组织裁撤"),
        "documents": ("F37", "F38", "F39", "F60", "F78"),
        "questions": (
            "拟减少多少人、占职工总数多少，具体经营或组织变化及持续期间是什么？",
            "哪些劳动合同已无法履行，是否做过协商变更、替代岗位或待岗安排？",
            "是否有工会、受保护员工及说明听取意见、行政报告的时间计划？",
        ),
    },
    {
        "intent": "democratic_procedure",
        "keywords": ("民主程序", "职代会", "职工代表大会", "工会盖章", "工会章", "哪些人签字", "谁签字"),
        "documents": ("R48", "R49", "R50", "R51", "R134"),
        "questions": (
            "本次是制定规章制度、调整薪酬等集体事项，还是具体员工解除前通知工会？",
            "工会或职代会如何建立、代表如何选举，参会和表决人数分别是多少？",
            "所在地及现有通知、签到、表决、协商、公示和版本材料有哪些？",
        ),
    },
    {
        "intent": "contract_signing_and_double_wage",
        "keywords": ("未签合同", "没签合同", "忘签", "补签", "倒签", "二倍工资", "双倍工资", "拒签合同", "拒签", "催签"),
        "documents": ("F66", "F67", "F68", "F69", "R8"),
        "questions": (
            "实际用工开始日、合同实际签署日和合同拟记载的起始日分别是哪一天？",
            "未及时签订是谁的原因，是否有催签、拒签或拖延的原始记录？",
            "企业希望补齐合同继续用工，还是已经需要处理二倍工资或终止用工争议？",
        ),
    },
    {
        "intent": "payroll_payment_and_declaration",
        "keywords": ("个人账户", "私人账户", "多个账户", "现金工资", "现金发工资", "亲属代领", "代领工资", "工资流水", "个税", "工资基数"),
        "documents": ("R66", "R69", "F72", "R47", "R68"),
        "questions": (
            "这些款项分别是固定工资、奖金提成、报销还是其他项目，涉及哪些月份和金额？",
            "实际付款凭证、工资表、员工签收或代领授权、个税申报和社保基数能否逐月对应？",
            "企业现在要解决的是历史整改、员工索薪、社保税务核查，还是重建工资支付制度？",
        ),
    },
    {
        "intent": "social_insurance",
        "keywords": ("不买社保", "不交社保", "不缴社保", "社保补贴", "放弃社保", "补缴社保", "社保基数"),
        "documents": ("R67", "R68", "R69", "R141", "R92"),
        "questions": (
            "涉及哪些员工、险种、月份和工资基数，目前是否仍在职？",
            "员工是否领取过社保补贴，是否已发生离职、工伤、医疗或投诉仲裁？",
            "企业所在地和当前参保状态是什么，希望补缴、协商还是应对争议？",
        ),
    },
    {
        "intent": "employer_change_and_continuity",
        "keywords": ("更换公司主体", "换公司签合同", "换主体签合同", "关联公司", "连续工龄", "切断工龄", "无固定期限", "混同用工"),
        "documents": ("R8", "R82", "R89", "R132", "R141"),
        "questions": (
            "新旧公司是否关联，员工岗位、地点、主管和业务是否实质变化？",
            "原单位是否结算经济补偿，是否已有三方调动、承继或解除文件？",
            "变更后工资、社保、考勤和日常管理分别由哪个主体负责？",
        ),
    },
    {
        "intent": "work_injury",
        "keywords": ("工伤", "职业病", "停工留薪", "伤残", "工伤认定"),
        "documents": ("R92", "R93", "R15", "R68"),
        "questions": (
            "事故发生时间、地点、经过和目前治疗诊断情况是什么？",
            "是否已参保、申报工伤、完成认定或劳动能力鉴定，当前卡在哪一步？",
            "企业需要申报材料、待遇测算、和解协议还是劳动关系处理方案？",
        ),
    },
    {
        "intent": "annual_leave",
        "keywords": ("年休假", "未休年假", "带薪年休假", "年假工资"),
        "documents": ("R54", "F72", "R132", "R135"),
        "questions": (
            "员工累计工作年限、入职时间以及争议年度分别是什么？",
            "公司已安排或员工已休多少天，是否有书面不休申请、休假审批和考勤记录？",
            "目前是在职安排年假、离职结算，还是已经发生仲裁争议？",
        ),
    },
    {
        "intent": "overage_employment",
        "keywords": ("超龄劳动者", "退休返聘", "达到退休年龄", "超过退休年龄", "退休人员"),
        "documents": ("R21", "R22", "R145", "R147", "R149"),
        "questions": (
            "劳动者是否已达到法定退休年龄，是否已按月领取基本养老金？",
            "实际岗位、管理方式、报酬、工作时间和工伤保险状态是什么？",
            "企业需要签订用工协议、继续参保、处理工伤，还是终止返聘？",
        ),
    },
    {
        "intent": "probation_assessment",
        "keywords": ("试用期", "不符合录用条件", "试用期辞退", "试用期考核", "转正"),
        "documents": ("R30", "R31", "R35", "F10", "F15"),
        "questions": (
            "试用期何时届满，企业希望转正、继续观察还是解除？",
            "录用条件和考核目标是否在入职前后书面确认，员工是否签收？",
            "哪些具体事实未达标，现有原始数据、辅导、考核和送达证据有哪些？",
        ),
    },
    {
        "intent": "termination",
        "keywords": ("辞退", "解除合同", "解除劳动合同", "裁员", "开除", "不能胜任", "严重违纪"),
        "documents": ("R133", "F55", "F57", "F58", "F61"),
        "questions": (
            "企业准备依据什么具体事实解除，事件发生时间和员工当前状态是什么？",
            "已有哪些制度签收、调查、考核、培训调岗、申辩、审批和送达证据？",
            "公司是否有工会，期望协商解除还是单方解除，最迟何时处理？",
        ),
    },
]


def _load_extension_intent_packs() -> list[dict]:
    registry_path = Path(__file__).resolve().parents[1] / "core" / "v1" / "intake" / "extension-routing-registry.json"
    if not registry_path.exists():
        return []
    data = json.loads(registry_path.read_text(encoding="utf-8"))
    existing = {row["intent"] for row in INTENT_PACKS}
    return [
        {
            "intent": row["intent"],
            "keywords": tuple(row["keywords"]),
            "documents": tuple(row["documents"]),
            "questions": tuple(row.get("questions", [])),
        }
        for row in data.get("intents", [])
        if row["intent"] not in existing
    ]


INTENT_PACKS.extend(_load_extension_intent_packs())


FALLBACK_QUESTIONS = [
    "现在最急需解决的是签合同、工资社保、考勤休假、调岗考核、违纪解除、工伤，还是退休返聘？",
    "企业希望最终实现什么结果：补齐手续、继续用工、调整安排、处理争议、解除终止，还是直接生成某份文书？",
    "关键事件发生在什么时间，公司和员工已经分别做过什么？",
]


GENERIC_STOP_TERMS = {
    "公司", "企业", "员工", "人员", "核心", "入职", "劳动", "合同", "协议", "文书", "一份", "请问", "如何", "怎么", "现在", "需要", "适用", "起草", "生成",
}

CATALOG_ANCHORS = (
    "竞业限制", "商业秘密", "保密协议", "加班", "调休", "销售提成", "股权激励", "培训服务期", "招聘", "背景调查", "离职证明",
)

TITLE_OVERRIDES = {
    "R8": ("劳动合同书（通用标准版）", "劳动合同与岗位合同"),
    "F66": ("劳动合同补签及签署确认书", "劳动合同订立与补签"),
}

DOCUMENT_FORM_TERMS = ("申请书", "确认书", "承诺书", "通知书", "协议", "合同", "制度", "答辩")


def load_documents(path: Path) -> dict[str, dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = list(data["documents"])
    extension_path = path.with_name("extension-documents.json")
    if extension_path.exists():
        rows.extend(json.loads(extension_path.read_text(encoding="utf-8"))["documents"])
    result = {row["id"]: row for row in rows}
    for document_id, (title, stage) in TITLE_OVERRIDES.items():
        if document_id in result:
            result[document_id] = {**result[document_id], "title": title, "stage": stage}
    return result


def _pack_score(query: str, pack: dict) -> tuple[int, list[str]]:
    matched = [word for word in pack["keywords"] if word in query]
    return sum(max(2, len(word)) for word in matched), matched


def _explicit_document_id(query: str) -> str | None:
    match = re.search(r"(?<![A-Z0-9])([RFX]\d{1,3})(?!\d)", query.upper())
    return match.group(1) if match else None


def _catalog_terms(query: str) -> list[str]:
    terms: set[str] = set()
    for run in re.findall(r"[\u4e00-\u9fff]{2,}", query):
        for size in range(2, min(8, len(run)) + 1):
            for start in range(0, len(run) - size + 1):
                term = run[start : start + size]
                if term not in GENERIC_STOP_TERMS:
                    terms.add(term)
    return sorted(terms, key=lambda value: (-len(value), value))


def _catalog_score(query: str, row: dict) -> tuple[int, list[str]]:
    haystack = " ".join(
        [row.get("title", ""), row.get("stage", ""), *row.get("aliases", [])]
    )
    matched = [term for term in _catalog_terms(query) if term in haystack]
    selected: list[str] = []
    for term in matched:
        if any(term in longer for longer in selected):
            continue
        selected.append(term)
        if len(selected) == 4:
            break
    score = sum(len(term) ** 2 for term in selected)
    title = row.get("title", "")
    if "协议" in query:
        score += 30 if "协议" in title else 0
        if any(kind in title for kind in ("申请书", "答辩状", "操作指引")):
            score -= 60
    if "审批单" in query:
        score += 25 if "审批" in title and ("单" in title or "表" in title) else 0
    return max(0, score), selected


def search_catalog(query: str, documents: dict[str, dict], limit: int = 5) -> list[tuple[str, int, list[str]]]:
    ranked = []
    anchors = [anchor for anchor in CATALOG_ANCHORS if anchor in query]
    for document_id, row in documents.items():
        haystack = " ".join([row.get("title", ""), row.get("stage", ""), *row.get("aliases", [])])
        if anchors and not any(anchor in haystack for anchor in anchors):
            continue
        score, terms = _catalog_score(query, row)
        if score:
            ranked.append((document_id, score, terms))
    return sorted(ranked, key=lambda item: (-item[1], documents[item[0]]["sort_key"]))[:limit]


def intake(query: str, documents: dict[str, dict]) -> IntakeResult:
    text = "".join(query.split())
    scored = [(pack, *_pack_score(text, pack)) for pack in INTENT_PACKS]
    pack, score, matched = max(scored, key=lambda item: item[1])
    explicit_id = _explicit_document_id(query)
    catalog_matches = search_catalog(query, documents, limit=8)

    vague = len(text) < 8 or text in {"员工有问题怎么办", "帮我处理员工", "劳动问题咨询", "需要一份文书", "怎么办"}
    generation_request = _contains_generation_request(text)
    requested_forms = [term for term in DOCUMENT_FORM_TERMS if term in text]
    available_titles = [documents[item]["title"] for item in pack["documents"] if item in documents] if score else []
    available_titles.extend(documents[item]["title"] for item, _, _ in catalog_matches)
    requested_form = requested_forms[0] if requested_forms else None
    form_mismatch = bool(requested_form) and not any(requested_form in title for title in available_titles)
    if generation_request and explicit_id not in documents and not vague and (
        (score == 0 and not catalog_matches) or form_mismatch
    ):
        return IntakeResult(
            mode="direct",
            clarity="clear",
            matched_intent="open_template_drafting",
            matched_keywords=_catalog_terms(query)[:5],
            candidate_documents=[],
            questions=[],
            next_action="文书库未命中：不联网、不先检索法规，直接按最接近的同类文书结构生成首份完整正文；检索核验和扩展入库均后置。",
        )
    if (score == 0 and explicit_id not in documents and not catalog_matches) or vague:
        return IntakeResult(
            mode="fallback",
            clarity="unclear",
            matched_intent=None,
            matched_keywords=[],
            candidate_documents=[],
            questions=FALLBACK_QUESTIONS,
            next_action="根据回答识别场景，再检索3至5份候选文书；不一次性展示全部基础问题。",
        )

    candidate_ids = list(pack["documents"]) if score else []
    trial_contract_request = "试用期" in text and "合同" in text and generation_request
    if trial_contract_request:
        candidate_ids = ["R8", *[item for item in candidate_ids if item != "R8"]]
    elif score and pack["intent"] == "probation_assessment":
        if any(term in text for term in ("辞退", "解除", "不符合录用条件")):
            preferred = ["R35", "F15", "R31", "R30", "F10"]
        elif any(term in text for term in ("考核", "不达标", "绩效")):
            preferred = ["R31", "R30", "R35", "F10", "F15"]
        else:
            preferred = candidate_ids
        candidate_ids = [item for item in preferred if item in candidate_ids]
    if explicit_id in documents:
        candidate_ids = [explicit_id] + [item for item in candidate_ids if item != explicit_id]
    if not score or len(candidate_ids) < 3:
        candidate_ids.extend(item for item, _, _ in catalog_matches if item not in candidate_ids)
    candidate_ids = [item for item in candidate_ids if item in documents][:5]
    catalog_by_id = {item: (catalog_score, terms) for item, catalog_score, terms in catalog_matches}
    candidates = [
        CandidateDocument(
            document_id=item,
            title=documents[item]["title"],
            stage=documents[item]["stage"],
            score=(100 if item == explicit_id else 0)
            + score
            + max(1, 5 - index)
            + catalog_by_id.get(item, (0, []))[0],
            reason=_candidate_reason(matched, catalog_by_id.get(item, (0, []))[1]),
        )
        for index, item in enumerate(candidate_ids)
    ]

    direct = generation_request and bool(candidates)
    if score:
        questions = [] if direct else list(pack["questions"][:3])
        matched_intent = pack["intent"]
    else:
        titles = "、".join(item.title for item in candidates[:3])
        questions = [
            f"已初步匹配到{titles}；你希望新建、修改、审查，还是处理已经发生的争议？",
            "涉及人员、关键事件和希望文书生效的时间点分别是什么？",
            "目前已经形成并可核验的合同、通知、签收、数据或其他证据有哪些？",
        ]
        matched_intent = "catalog_search"
    return IntakeResult(
        mode="direct" if direct else "targeted",
        clarity="clear" if direct or len(matched) >= 2 else "partial",
        matched_intent=matched_intent,
        matched_keywords=matched or catalog_matches[0][2],
        candidate_documents=candidates,
        questions=questions,
        next_action=(
            "立即生成首份完整文书；缺失信息使用清晰占位符，文书后再邀请用户补充优化。"
            if direct else
            "首次回复先给出方案和风险；如用户需要文书，则立即生成并以占位符处理缺项。"
        ),
        route_adjustment_notice=(
            "用户要的是试用期合同。应生成标题和内容均明确包含试用期及录用条件的劳动合同，而不是单独试用期合同；正文之后必须说明替代原因、原做法的法律后果和三个月试用期对应的合同期限条件，不得静默替换。"
            if trial_contract_request else None
        ),
    )


def _contains_generation_request(text: str) -> bool:
    return any(word in text for word in (
        "生成", "起草", "拟定", "写一份", "做一份", "修改", "审查", "制作", "出一份",
        "需要文书", "提供文书", "给出文书", "出文书", "文书要求",
    ))


def _candidate_reason(intent_terms: list[str], catalog_terms: list[str]) -> str:
    parts = []
    if intent_terms:
        parts.append(f"场景关键词：{'、'.join(intent_terms)}")
    if catalog_terms:
        parts.append(f"目录标题匹配：{'、'.join(catalog_terms)}")
    return "；".join(parts) + "；用于立即生成首份文书，缺失信息以占位符保留。"
