from __future__ import annotations

import re
from typing import Any


LEVEL_ORDER = {"basic": 0, "intermediate": 1, "advanced": 2}

IDENTITY_TERMS = {
    "hr": ("我是hr", "我是人事", "人力资源", "员工关系", "招聘", "考勤", "薪酬"),
    "legal": ("我是法务", "公司法务", "合规", "仲裁答辩", "举证", "诉讼策略", "法律审查"),
    "owner": ("我是老板", "我是企业主", "创始人", "公司负责人", "经营成本", "管理团队"),
}

PROFESSIONAL_TERMS = (
    "举证责任", "构成要件", "民主程序", "工会程序", "违法解除", "经济补偿",
    "赔偿金", "仲裁请求", "证据链", "裁判口径", "劳动关系", "规章制度",
)

COMPLEXITY_GROUPS = {
    "multiple_entities": ("关联公司", "多个主体", "混同用工", "劳务派遣", "外包"),
    "multiple_actions": ("多次调岗", "多次处分", "续签", "第三次合同", "先后"),
    "evidence_conflict": ("证据矛盾", "前后不一致", "没有书面", "补证", "录音"),
    "proceeding": ("已经仲裁", "劳动仲裁", "已经起诉", "开庭", "答辩"),
    "special_case": ("工伤", "竞业限制", "高管", "经济性裁员", "群体裁员"),
    "local_rule": ("地方口径", "当地规定", "广东", "北京", "上海", "重庆", "深圳"),
    "high_impact": ("金额较大", "几十万", "上百万", "核心员工", "影响经营"),
}


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def _infer_identity(text: str, previous: dict[str, Any]) -> tuple[str, str]:
    matches = [identity for identity, terms in IDENTITY_TERMS.items() if _contains_any(text, terms)]
    if len(matches) == 1:
        explicit = any(term.startswith("我是") and term in text for term in IDENTITY_TERMS[matches[0]])
        return matches[0], "high" if explicit else "medium"
    if len(matches) > 1:
        return "unknown", "low"
    prior_identity = previous.get("inferred_identity", "unknown")
    prior_confidence = previous.get("identity_confidence", "low")
    if prior_identity != "unknown" and prior_confidence in {"medium", "high"}:
        return prior_identity, prior_confidence
    return "unknown", "low"


def _level_score(text: str, cumulative_fact_count: int) -> tuple[int, list[str]]:
    score = 0
    signals: list[str] = []
    compact = re.sub(r"\s+", "", text)
    if len(compact) >= 40:
        score += 1
        signals.append("substantive_length")
    if len(compact) >= 100:
        score += 1
        signals.append("extended_detail")

    detail_groups = (
        bool(re.search(r"20\d{2}[年./-]|\d+[个月天年]", text)),
        _contains_any(text, ("岗位", "职务", "部门", "员工", "公司")),
        _contains_any(text, ("已经", "曾经", "目前", "准备", "签过", "发过", "通知")),
        _contains_any(text, ("证据", "合同", "制度", "录音", "邮件", "微信", "考勤")),
        _contains_any(text, ("请生成", "帮我写", "需要文书", "想辞退", "想调岗", "应诉", "降低风险")),
    )
    detail_count = sum(detail_groups)
    if detail_count >= 2:
        score += 2
        signals.append("multiple_fact_dimensions")
    if detail_count >= 4 or cumulative_fact_count >= 5:
        score += 1
        signals.append("fact_pattern_complete")

    professional_count = sum(term in text for term in PROFESSIONAL_TERMS)
    if professional_count >= 2:
        score += 2
        signals.append("professional_terms")
    if _contains_any(text, ("律师版", "详细版", "法律依据", "系统方案", "实施步骤", "举证方案")):
        score += 2
        signals.append("advanced_output_requested")
    return score, signals


def calibrate_user_profile(
    message: str,
    previous: dict[str, Any] | None = None,
    *,
    turn_count: int = 1,
    cumulative_fact_count: int = 0,
    additional_complexity_signals: list[str] | None = None,
    consultation_prompt_shown: bool = False,
    substantive_output_ready: bool = False,
) -> dict[str, Any]:
    previous = previous or {}
    text = str(message or "").strip().lower()
    score, signals = _level_score(text, cumulative_fact_count)
    if score >= 6:
        level = "advanced"
    elif score >= 3:
        level = "intermediate"
    else:
        level = "basic"

    prior_level = previous.get("level")
    if len(re.sub(r"\s+", "", text)) <= 8 and prior_level in LEVEL_ORDER:
        level = prior_level
        signals.append("short_follow_up_preserved")
    elif prior_level in LEVEL_ORDER and abs(LEVEL_ORDER[level] - LEVEL_ORDER[prior_level]) > 1:
        direction = 1 if LEVEL_ORDER[level] > LEVEL_ORDER[prior_level] else -1
        level = next(item for item, order in LEVEL_ORDER.items() if order == LEVEL_ORDER[prior_level] + direction)
        signals.append("gradual_recalibration")

    identity, identity_confidence = _infer_identity(text, previous)
    complexity_signals = list(previous.get("complexity_signals", []))
    for name, terms in COMPLEXITY_GROUPS.items():
        if _contains_any(text, terms) and name not in complexity_signals:
            complexity_signals.append(name)
    for name in additional_complexity_signals or []:
        if name and name not in complexity_signals:
            complexity_signals.append(name)

    question_limit = {"basic": 1, "intermediate": 2, "advanced": 3}[level]
    response_style = {
        "basic": "plain_action_first",
        "intermediate": "steps_evidence_and_main_rules",
        "advanced": "legal_elements_evidence_procedure_and_alternatives",
    }[level]
    consultation_eligible = (
        turn_count >= 3
        and level in {"intermediate", "advanced"}
        and len(complexity_signals) >= 2
        and substantive_output_ready
        and not consultation_prompt_shown
    )
    return {
        "level": level,
        "level_signals": list(dict.fromkeys(signals)),
        "inferred_identity": identity,
        "identity_confidence": identity_confidence,
        "response_style": response_style,
        "question_limit": question_limit,
        "complexity_signals": complexity_signals,
        "consultation_prompt_eligible": consultation_eligible,
    }
