<p align="center">
  <img src="assets/logo.png" alt="铸言企业用工文书助手" width="180">
</p>

# 铸言企业用工文书助手

**Zhuyan Enterprise Employment Document Assistant**

面向中国境内企业用工场景的文书生成 Skill。用户用日常语言说明问题后，系统优先在首轮直接生成可填写、可继续优化的劳动合同、协议、通知、制度、申请、确认书、承诺书、答辩等完整文书，并在正文之后提示主要风险和替代方案。

## 与通用大模型的区别

- 运行时目录覆盖235份基础文书能力卡及扩展文书能力卡，按企业用工场景、证据、程序和文书类型进行匹配。
- 明确要求文书时首轮先交付正文，不用冗长问卷阻断输出；缺失的姓名、日期、工资等使用清晰占位符。
- 库内文书走单次快速路径；库外文书先按最接近的同类结构起草，外部模板和法规核验后置。
- 对可能不合规的经营要求进行实质风险分析：形成可审阅文本，再说明效力、后果和更稳妥方案；不伪造事实、签字、证据或历史日期。
- 支持DOCX、Markdown和JSON交付；DOCX自动加入“铸言 企业用工文书”页眉、页码和免责声明。

> 本仓库发布的是Skill运行程序、能力目录及规则层，不包含八卷原始DOCX文书。原始文书及未公开底库著作权不因本仓库公开而转让或开放。

## 适用场景

招聘录用、劳动合同、试用期考核、绩效PIP、调岗调薪、工资社保、工时休假、违纪调查、协商解除、单方解除、竞业限制、工伤、退休返聘及劳动争议应对等。

## 安装

### Codex

1. 下载本仓库源码或Release压缩包。
2. 将仓库内容解压到：
   - Windows：`%USERPROFILE%\.codex\skills\china-employment-document-advisor`
   - macOS / Linux：`~/.codex/skills/china-employment-document-advisor`
3. 重新打开Codex，在任务中调用 `$china-employment-document-advisor`，或直接提出企业用工文书需求。

### 独立运行时（可选）

需要Python 3.12：

```bash
python -m pip install -r requirements.txt
python scripts/skill_runtime.py input.json output.json
```

统一入口和JSON契约见 [`references/runtime-contract.md`](references/runtime-contract.md)。Docker部署属于可选方式，HTTP服务需设置环境变量 `EMPLOYMENT_SKILL_API_KEY`。

## 示例

- `销售员工试用期业绩未达标，请生成考核结果通知书和不符合录用条件解除通知书，姓名和日期留空。`
- `员工入职三个月忘记签劳动合同，请先生成补签及签署确认书，再简要提示风险。`
- `公司自媒体账号由员工手机号注册，请生成账号使用、内容归属和离职交接协议。`

## 隐私与安全

- 不要在GitHub Issue、Discussion或公开日志中提交真实身份证号、银行账户、病历、工资明细、客户资料或完整争议卷宗。
- 默认首轮生成不需要联网；精确法条、最新政策和地方口径应在正式使用前另行核验。
- 不得利用本项目伪造、倒签、销毁或隐匿证据。

## 法律与使用声明

法律文书和风险提示不代表法律意见，内容仅供参考，使用应自行承担风险和责任。正式签署或实施前，应结合真实事实、证据、当地规则和裁判尺度复核。

本项目采用专有有限使用许可，详见 [`LICENSE`](LICENSE)。未经许可不得转售、公开再分发、提取文书能力库或用于建立竞争性文书产品。

---

## English

Zhuyan Enterprise Employment Document Assistant is a Chinese-language Skill for PRC employment-document drafting. It routes a user's plain-language request to a catalog of 235 base document capabilities, produces a complete fillable first draft before optional follow-up questions, and places concise risk notes and safer alternatives after the document.

It covers hiring, employment contracts, probation assessment, performance improvement, transfer and pay adjustment, payroll and social insurance, working time and leave, misconduct investigation, termination, non-compete, work injury, post-retirement engagement, and labor-dispute response.

This repository contains the Skill runtime, capability catalog, and rule layer. It does **not** publish the original eight-volume DOCX corpus. The output is for reference only and is not legal advice. Review the facts, evidence, local rules, and current adjudication practice before use.

