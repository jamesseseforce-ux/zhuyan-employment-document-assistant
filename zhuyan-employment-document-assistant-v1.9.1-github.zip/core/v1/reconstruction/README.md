# 动态文书重构层 V1

本层把问诊和文书路由结果转换为按个案事实生成的文书内容，不直接套用八卷范文正文。

## 当前覆盖

- 为R26、R30、F10、R31/F11、F13、F14、R35/F15、F6建立10份文书规格；
- 每份规格记录适用阶段、轨道、必需事实、条款模块和禁止生成条件；
- 进阶解除案例可根据同一组主体、日期、考核事实和证据生成F13、F14、F15三份一致文本；
- 前置文件只允许引用真实形成的既有材料，缺失时标记`do_not_backfill`，不生成倒签版本；
- 企业没有工会时不虚构工会通知，不自动用职工代表、区域或街道工会替代；
- 解除理由固定为《劳动合同法》第三十九条第一项，禁止争议后增加其他理由；
- 工资支付、解除证明和社保档案手续不以员工签字或完成交接为前提。

## 文件

- `schemas/reconstruction-scenario.schema.json`：动态重构输入事实契约；
- `schemas/reconstruction-result.schema.json`：文书包输出契约；
- `config/golden-chain-document-specs.json`：10份文书的字段、模块和生成边界；
- `tests/advanced-probation-termination-input.json`：脱敏示例事实；
- `tests/advanced-probation-termination-result.json`：F13/F14/F15定制文书包；
- `validation-report.json`：构建验收和文件哈希。

运行逻辑位于`tools/dynamic_reconstruction_engine.py`；生成正式配置使用`tools/build_reconstruction_v1.py`，避免只手工修改生成产物。

## 当前边界

V1输出结构化文本，尚未进入DOCX排版和四平台适配。八卷原文继续仅作为内部受控参考，不进入公开Skill包。其他用工阶段将在相同Schema和停止规则下逐步扩展。
