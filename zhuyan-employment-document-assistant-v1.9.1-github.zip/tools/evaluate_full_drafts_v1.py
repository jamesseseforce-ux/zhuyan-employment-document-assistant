from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

try:
    from tools.full_document_generator_v1 import FullDraftResult
except ModuleNotFoundError:
    from full_document_generator_v1 import FullDraftResult


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DraftEvaluation(StrictModel):
    case_id: str
    passed: bool
    score: int
    dimensions: dict[str, bool]
    failures: list[str]


FORBIDDEN_PHRASES = [
    "企业必胜",
    "彻底封死风险",
    "最高法律效力",
    "永久放弃仲裁",
    "逾期视为无异议",
]


def _render_value(value: Any) -> str:
    if isinstance(value, list):
        return "；".join(str(item) for item in value)
    if isinstance(value, dict):
        return "；".join(f"{key}：{item}" for key, item in value.items())
    return str(value)


def evaluate_full_draft(case: dict, result: FullDraftResult) -> DraftEvaluation:
    texts = [item.content for item in result.documents]
    combined = "\n".join(texts)
    facts = case["facts"]
    failures: list[str] = []

    expected_document_count = len(case["selected_document_ids"])
    document_count = result.drafting_allowed and len(result.documents) == expected_document_count
    if not document_count:
        failures.append("生成文书数量与选定文书不一致。")

    fact_fidelity = True
    for document in result.documents:
        for field in document.source_fact_fields:
            value = _render_value(facts[field])
            if value and value not in document.content:
                fact_fidelity = False
                failures.append(f"{document.document_id}未呈现来源事实：{field}。")

    route_fields = ["fixed_legal_route", "decision_basis"]
    route_values = [_render_value(facts[field]) for field in route_fields if field in facts]
    legal_route = not route_values or all(value in combined for value in route_values)
    if not legal_route:
        failures.append("固定法律路线或决定依据未进入正文。")

    evidence_traceability = all(
        evidence in document.content
        for document in result.documents
        for evidence in document.evidence_requirements
    )
    if not evidence_traceability:
        failures.append("证据要求未完整进入支持材料清单。")

    time_fields = ["event_or_effective_date", "notice_date", "effective_date", "signing_date", "record_date"]
    time_values = [_render_value(facts[field]) for field in time_fields if field in facts]
    procedure_timing = all(value in combined for value in time_values)
    if not procedure_timing:
        failures.append("关键形成、生效或签署时间未完整呈现。")

    shared_fields = ["employer_name", "locality", "case_objective", "event_or_effective_date"]
    consistency = all(
        _render_value(facts[field]) in document.content
        for document in result.documents
        for field in shared_fields
        if field in facts
    )
    if not consistency:
        failures.append("多文书共享事实未保持一致。")

    executability = all(
        ("签字" in document.content or "盖章" in document.content)
        and "支持材料及核验" in document.content
        for document in result.documents
    )
    if not executability:
        failures.append("正文缺少签署或支持材料模块。")

    language_guard = not any(phrase in combined for phrase in FORBIDDEN_PHRASES)
    if not language_guard:
        failures.append("正文含有禁止使用的绝对化或权利剥夺表述。")

    dimensions = {
        "document_count": bool(document_count),
        "fact_fidelity": fact_fidelity,
        "legal_route": legal_route,
        "evidence_traceability": evidence_traceability,
        "procedure_timing": procedure_timing,
        "cross_document_consistency": consistency,
        "executability": executability,
        "language_guard": language_guard,
    }
    score = round(sum(dimensions.values()) / len(dimensions) * 100)
    critical = document_count and fact_fidelity and legal_route and language_guard
    return DraftEvaluation(
        case_id=case["case_id"],
        passed=critical and score >= 88,
        score=score,
        dimensions=dimensions,
        failures=failures,
    )
