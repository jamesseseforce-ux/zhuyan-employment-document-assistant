from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PriorDocument(StrictModel):
    document_id: Literal["F6", "R26", "R30", "F10", "R31", "F11"]
    document_number: str
    formed_date: date
    signed_or_delivered: bool


class EvidenceItem(StrictModel):
    evidence_id: str
    name: str
    formed_date: date
    status: Literal["verified", "reported", "missing"]


class AssessmentFinding(StrictModel):
    condition_reference: str
    agreed_standard: str
    actual_result: str
    evidence_ids: list[str] = Field(min_length=1)


class ReconstructionScenario(StrictModel):
    case_id: str
    selected_track: Literal["standard", "advanced"]
    current_stage: Literal["decision"] = "decision"
    employer_name: str
    employer_has_union: bool | None
    local_rules_checked: bool
    employee_name: str
    employee_id_number: str
    department: str
    position: str
    employment_start: date
    contract_signed_date: date
    contract_end: date
    probation_start: date
    probation_end: date
    probation_previously_used: bool
    prior_documents: list[PriorDocument]
    assessment_date: date
    assessment_score: float
    pass_score: float
    findings: list[AssessmentFinding] = Field(min_length=1)
    evidence: list[EvidenceItem]
    interview_date: date
    union_notice_date: date | None = None
    termination_notice_date: date
    termination_effective_date: date
    delivery_method: Literal["onsite", "ems", "electronic_combined"]
    delivery_detail: str
    handover_deadline: str


class DocumentPlanItem(StrictModel):
    document_id: str
    title: str
    action: Literal["use_existing", "generate_now", "conditional", "excluded", "do_not_backfill"]
    reason: str


class GeneratedDocument(StrictModel):
    document_id: str
    title: str
    content: str


class ReconstructionResult(StrictModel):
    case_id: str
    status: Literal["ready", "draft_ready_with_review", "needs_information", "stop_and_review"]
    fixed_termination_basis: str
    questions: list[str]
    risk_flags: list[str]
    document_plan: list[DocumentPlanItem]
    generated_documents: list[GeneratedDocument]
    consistency_checks: dict[str, bool]


DOCUMENT_SPECS = [
    {"document_id": "F6", "title": "法律文书送达地址确认书", "stage": "onboarding", "tracks": ["advanced"], "required_fields": ["employee_name", "employee_id_number", "delivery_detail"], "modules": ["party_identity", "delivery_channels", "address_change"], "guard": "仅使用入职或变更时真实形成的文件；解除阶段不得倒签。"},
    {"document_id": "R26", "title": "员工录用条件确认函", "stage": "onboarding", "tracks": ["standard", "advanced"], "required_fields": ["position", "probation_start", "probation_end"], "modules": ["party_identity", "probation_timeline", "objective_conditions"], "guard": "录用条件须在考核事实发生前明确并送达；不得用考核结果反向编写条件。"},
    {"document_id": "R30", "title": "试用期目标责任书", "stage": "onboarding", "tracks": ["standard", "advanced"], "required_fields": ["position", "pass_score"], "modules": ["objective_targets", "data_sources", "acceptance_threshold"], "guard": "指标、权重、数据源和合格线必须前置、客观且岗位相关；不得在考核后补签。"},
    {"document_id": "F10", "title": "试用期员工阶段性沟通与辅导记录表", "stage": "monitoring", "tracks": ["standard", "advanced"], "required_fields": ["findings", "evidence"], "modules": ["progress_review", "gap_analysis", "support_actions"], "guard": "只能记录当时已经发生的沟通和支持；员工拒签不等于事实不存在，也不得事后补造。"},
    {"document_id": "R31", "title": "试用期综合考核表", "stage": "assessment", "tracks": ["standard"], "required_fields": ["assessment_date", "assessment_score", "findings"], "modules": ["standard_actual_comparison", "evidence_index", "decision"], "guard": "基础轨道使用；不得与F11重复生成。"},
    {"document_id": "F11", "title": "试用期转正或淘汰述职与综合评定表", "stage": "assessment", "tracks": ["advanced"], "required_fields": ["assessment_date", "assessment_score", "findings"], "modules": ["standard_actual_comparison", "employee_statement", "evidence_index", "decision"], "guard": "进阶轨道使用；考核结论必须逐项对应既定条件和原始证据。"},
    {"document_id": "F13", "title": "试用期辞退沟通面谈记录表", "stage": "decision", "tracks": ["advanced"], "required_fields": ["interview_date", "findings"], "modules": ["fact_disclosure", "employee_statement", "handover_arrangement"], "guard": "不得诱导个人辞职、预设员工承认、写入放弃仲裁或未核实的权益清结。"},
    {"document_id": "F14", "title": "试用期不符合录用条件解除事先通知工会函", "stage": "decision", "tracks": ["advanced"], "required_fields": ["union_notice_date", "findings"], "modules": ["fixed_reason", "fact_summary", "union_notice", "attachments"], "guard": "仅企业已建立工会时生成；是事先通知并研究意见，不是请求批准，不得约定逾期视为无异议。"},
    {"document_id": "R35", "title": "试用期不符合录用条件解除劳动合同通知书", "stage": "decision", "tracks": ["standard"], "required_fields": ["termination_notice_date", "findings", "delivery_method"], "modules": ["fixed_reason", "fact_summary", "termination_decision", "settlement", "delivery"], "guard": "基础轨道使用；解除理由不得在争议中另行增加，且须在试用期内完成决定和送达。"},
    {"document_id": "F15", "title": "试用期不符合录用条件解除劳动合同通知书", "stage": "decision", "tracks": ["advanced"], "required_fields": ["termination_notice_date", "findings", "delivery_method"], "modules": ["fixed_reason", "evidence_chain", "union_status", "termination_decision", "settlement", "delivery"], "guard": "进阶轨道使用；不作必胜承诺，不以交接为支付工资或出具离职证明的前提。"},
]


def _document_map(scenario: ReconstructionScenario) -> dict[str, PriorDocument]:
    return {item.document_id: item for item in scenario.prior_documents}


def _evidence_map(scenario: ReconstructionScenario) -> dict[str, EvidenceItem]:
    return {item.evidence_id: item for item in scenario.evidence}


def _fmt(value: date) -> str:
    return value.strftime("%Y年%m月%d日")


def _add_months(value: date, months: int) -> date:
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def _maximum_probation_months(scenario: ReconstructionScenario) -> int:
    inclusive_contract_days = (scenario.contract_end - scenario.employment_start).days + 1
    if inclusive_contract_days < 90:
        return 0
    if inclusive_contract_days < 365:
        return 1
    if inclusive_contract_days < 1095:
        return 2
    return 6


def _findings_text(scenario: ReconstructionScenario) -> str:
    evidence = _evidence_map(scenario)
    rows = []
    for index, finding in enumerate(scenario.findings, 1):
        names = "、".join(evidence[item].name for item in finding.evidence_ids if item in evidence)
        rows.append(
            f"{index}. 对应录用条件：{finding.condition_reference}；既定标准：{finding.agreed_standard}；"
            f"实际结果：{finding.actual_result}；支持材料：{names}。"
        )
    return "\n".join(rows)


def _plan(scenario: ReconstructionScenario, can_generate: bool) -> list[DocumentPlanItem]:
    prior = _document_map(scenario)
    plan = []
    for spec in DOCUMENT_SPECS:
        doc_id = spec["document_id"]
        if doc_id in prior:
            action = "use_existing" if prior[doc_id].signed_or_delivered else "do_not_backfill"
            reason = "使用真实形成并签署/送达的既有材料。" if action == "use_existing" else "文件未签署或未送达，不得在解除阶段倒签补造。"
        elif doc_id in {"R31", "R35"} and scenario.selected_track == "advanced":
            action, reason = "excluded", "进阶轨道使用F11/F15，避免同功能文书重复或理由口径冲突。"
        elif doc_id in {"F11", "F13", "F14", "F15", "F6"} and scenario.selected_track == "standard":
            action, reason = "excluded", "基础轨道不自动叠加进阶文书。"
        elif doc_id == "F14" and scenario.employer_has_union is False:
            action, reason = "excluded", "企业确认未建立工会，不虚构工会或以职工代表、区域工会自动替代。"
        elif doc_id in {"F13", "F14", "F15"} and scenario.selected_track == "advanced":
            action = "generate_now" if can_generate else "conditional"
            reason = "解除阶段的现时文书。" if can_generate else "待关键事实、证据和程序补齐后生成。"
        elif doc_id == "R35" and scenario.selected_track == "standard":
            action = "generate_now" if can_generate else "conditional"
            reason = "基础轨道解除通知。" if can_generate else "待关键事实、证据和程序补齐后生成。"
        else:
            action, reason = "do_not_backfill", "该前置节点没有真实既有文件，解除阶段不得补签补造。"
        plan.append(DocumentPlanItem(document_id=doc_id, title=spec["title"], action=action, reason=reason))
    return plan


def _interview_document(scenario: ReconstructionScenario) -> GeneratedDocument:
    content = f"""试用期考核结果沟通面谈记录

一、基本信息
员工：{scenario.employee_name}（身份证号：{scenario.employee_id_number}）
部门及岗位：{scenario.department}／{scenario.position}
面谈日期：{_fmt(scenario.interview_date)}

二、公司告知的考核事实
公司已向员工说明，本次评定仅依据入职时已经明确的录用条件、目标责任书以及试用期内形成的客观材料：
{_findings_text(scenario)}
综合考核得分为{scenario.assessment_score:g}分，既定合格线为{scenario.pass_score:g}分。

三、员工陈述与异议
员工对上述事实的意见：____________________________________________
员工提交或要求核验的材料：________________________________________
公司对异议的回应及后续核验：______________________________________

四、后续安排
公司告知员工，将根据已经固定的事实、证据和法定程序另行作出书面决定。本记录不要求员工承认考核结论，不预设员工辞职，也不包含放弃仲裁、工资或其他法定权利的承诺。
如依法解除，工作交接截止时间暂定为：{scenario.handover_deadline}；工资、报销及其他依法应付款项按照实际履行情况另行核对结算，不以员工签署本记录为前提。

员工陈述人签字：____________  面谈人签字：____________  记录人签字：____________
"""
    return GeneratedDocument(document_id="F13", title="试用期考核结果沟通面谈记录", content=content)


def _union_document(scenario: ReconstructionScenario) -> GeneratedDocument:
    content = f"""关于拟解除{scenario.employee_name}劳动合同的事先通知工会函

致：{scenario.employer_name}工会委员会

{scenario.employee_name}于{_fmt(scenario.employment_start)}入职，现任{scenario.department}{scenario.position}。双方约定试用期自{_fmt(scenario.probation_start)}至{_fmt(scenario.probation_end)}。

公司拟固定以《劳动合同法》第三十九条第一项“在试用期间被证明不符合录用条件”为唯一解除依据。现有事实如下：
{_findings_text(scenario)}
综合考核得分为{scenario.assessment_score:g}分，低于既定合格线{scenario.pass_score:g}分。

根据《劳动合同法》第四十三条，公司于{_fmt(scenario.union_notice_date)}将拟解除的事实、理由和依据事先通知工会，请工会提出意见。公司将研究工会意见，并将处理结果书面通知工会。本函不以工会批准为生效条件，也不将逾期未回复推定为无异议。

附件：录用条件确认材料、目标责任材料、阶段辅导记录、综合评定材料及对应客观证据目录。

{scenario.employer_name}（盖章）
日期：{_fmt(scenario.union_notice_date)}

工会意见：________________________________________________________
工会负责人/授权代表签字：____________  工会盖章：____________
日期：____________
"""
    return GeneratedDocument(document_id="F14", title="拟解除劳动合同事先通知工会函", content=content)


def _termination_document(scenario: ReconstructionScenario, document_id: str) -> GeneratedDocument:
    union_text = ""
    if scenario.employer_has_union:
        union_text = f"公司已于{_fmt(scenario.union_notice_date)}将本次拟解除的事实、理由和依据事先通知工会，并将依法研究、回复工会意见。"
    else:
        union_text = "公司确认目前未建立工会，本文不虚构工会通知、工会复函或职工代表替代程序；签发前仍须结合用工所在地规则复核。"
    content = f"""解除劳动合同通知书
（试用期间被证明不符合录用条件）

致：{scenario.employee_name}（身份证号：{scenario.employee_id_number}）

您于{_fmt(scenario.employment_start)}入职{scenario.employer_name}，任{scenario.department}{scenario.position}。双方劳动合同于{_fmt(scenario.contract_signed_date)}签订，约定试用期自{_fmt(scenario.probation_start)}至{_fmt(scenario.probation_end)}。

一、解除所依据的既定录用条件和客观事实
公司本次决定仅依据入职及试用期内已经形成、向您明确并用于本次考核的材料。具体事实如下：
{_findings_text(scenario)}
{_fmt(scenario.assessment_date)}形成的综合考核结果为{scenario.assessment_score:g}分，低于既定合格线{scenario.pass_score:g}分。

二、解除决定
根据《劳动合同法》第二十一条、第三十九条第一项，公司以“在试用期间被证明不符合录用条件”为本次解除的唯一事实和法律依据，决定于{_fmt(scenario.termination_effective_date)}解除与您的劳动合同。本通知不增加其他解除事由。

三、工会程序
{union_text}

四、工资结算、证明和交接
在本次解除被依法认定符合第三十九条第一项的前提下，不产生第四十六条规定的经济补偿。公司仍将依法核对并支付截至解除日的工资及其他应付款项，在解除时出具解除证明，并依法办理档案和社会保险关系转移手续。上述义务不以您签署本通知或完成交接作为前提。
请于{scenario.handover_deadline}前，与指定人员核对工作资料和公司资产；如对交接清单存在异议，可在清单中书面注明。

五、送达记录
通知签发日期：{_fmt(scenario.termination_notice_date)}
送达方式：{scenario.delivery_method}
送达详情：{scenario.delivery_detail}
员工签收或陈述：__________________________________________________
送达人：____________  见证人：____________  时间：____________

{scenario.employer_name}（盖章）
"""
    return GeneratedDocument(document_id=document_id, title="试用期不符合录用条件解除劳动合同通知书", content=content)


def reconstruct(scenario: ReconstructionScenario) -> ReconstructionResult:
    prior = _document_map(scenario)
    evidence = _evidence_map(scenario)
    questions: list[str] = []
    risks: list[str] = []
    hard_stop = False

    required_prior = {"R26", "R30", "R31"} if scenario.selected_track == "standard" else {"F6", "R26", "R30", "F10", "F11"}
    missing_prior = sorted(required_prior - set(prior))
    unsigned_prior = sorted(item for item in required_prior & set(prior) if not prior[item].signed_or_delivered)
    if missing_prior:
        questions.append(f"请确认是否真实存在并提供以下前置材料：{'、'.join(missing_prior)}；不存在时不得补签。")
    if unsigned_prior:
        risks.append(f"以下前置材料未签署或未送达，不能作为已完成节点：{'、'.join(unsigned_prior)}。")
        hard_stop = True

    if scenario.contract_signed_date > scenario.employment_start:
        risks.append("劳动合同签署日晚于实际用工开始日，需另行评估书面合同及二倍工资风险。")
    maximum_months = _maximum_probation_months(scenario)
    latest_probation_end = _add_months(scenario.probation_start, maximum_months) - timedelta(days=1) if maximum_months else scenario.probation_start - timedelta(days=1)
    probation_length_valid = scenario.probation_end <= latest_probation_end
    if scenario.contract_end < scenario.employment_start:
        risks.append("劳动合同终止日早于实际用工开始日，合同时间数据冲突。")
        hard_stop = True
    if not probation_length_valid:
        risks.append(f"当前合同期限对应的试用期最长为{maximum_months}个月，录入的试用期超过法定上限。")
        hard_stop = True
    if scenario.probation_previously_used:
        risks.append("同一用人单位与同一劳动者已经约定过试用期，不得再次约定。")
        hard_stop = True

    chronological_prior = True
    for doc_id in required_prior & set(prior):
        formed = prior[doc_id].formed_date
        if formed > scenario.assessment_date or (doc_id == "R26" and formed > scenario.employment_start):
            risks.append(f"{doc_id}的形成日期与入职或考核时间倒置，不能作为前置证据自动生成解除文书。")
            chronological_prior = False
            hard_stop = True
    if not (scenario.probation_start <= scenario.assessment_date <= scenario.probation_end):
        risks.append("考核日期不在约定试用期内。")
        hard_stop = True
    if scenario.termination_notice_date > scenario.probation_end or scenario.termination_effective_date > scenario.probation_end:
        risks.append("解除通知或解除生效日晚于试用期届满日，不能使用第三十九条第一项路径自动生成。")
        hard_stop = True
    if scenario.termination_notice_date < scenario.assessment_date:
        risks.append("解除通知早于终期考核形成日期，时间链倒置。")
        hard_stop = True
    if scenario.assessment_score >= scenario.pass_score:
        risks.append("考核总分已达到既定合格线，现有数据与不符合录用条件结论冲突。")
        hard_stop = True

    used_evidence = {item for finding in scenario.findings for item in finding.evidence_ids}
    unknown_evidence = sorted(used_evidence - set(evidence))
    unverified_evidence = sorted(item for item in used_evidence & set(evidence) if evidence[item].status != "verified")
    if unknown_evidence:
        questions.append(f"请提供并编号以下尚未入库的证据：{'、'.join(unknown_evidence)}。")
    if unverified_evidence:
        questions.append(f"请核验以下证据的原件、形成时间和数据来源：{'、'.join(unverified_evidence)}。")

    if scenario.employer_has_union is None:
        questions.append("企业是否已经依法建立工会？该答案决定是否生成F14及工会程序段落。")
    elif scenario.employer_has_union:
        if scenario.union_notice_date is None:
            questions.append("请提供向本企业工会事先通知的日期和送达记录。")
        elif scenario.union_notice_date > scenario.termination_notice_date:
            risks.append("工会通知日晚于解除通知日，程序时间倒置。")
            hard_stop = True

    can_generate = not hard_stop and not questions
    if hard_stop:
        status = "stop_and_review"
    elif questions:
        status = "needs_information"
    elif not scenario.local_rules_checked:
        status = "draft_ready_with_review"
    else:
        status = "ready"

    generated: list[GeneratedDocument] = []
    if can_generate:
        if scenario.selected_track == "advanced":
            generated.append(_interview_document(scenario))
            if scenario.employer_has_union:
                generated.append(_union_document(scenario))
            generated.append(_termination_document(scenario, "F15"))
        else:
            generated.append(_termination_document(scenario, "R35"))

    checks = {
        "reason_is_fixed": True,
        "assessment_within_probation": scenario.probation_start <= scenario.assessment_date <= scenario.probation_end,
        "probation_length_valid": probation_length_valid,
        "single_probation_only": not scenario.probation_previously_used,
        "prior_documents_chronological": chronological_prior,
        "notice_within_probation": scenario.termination_notice_date <= scenario.probation_end,
        "effective_date_within_probation": scenario.termination_effective_date <= scenario.probation_end,
        "findings_reference_known_evidence": not unknown_evidence,
        "all_used_evidence_verified": not unverified_evidence,
        "union_sequence_valid": not scenario.employer_has_union or (scenario.union_notice_date is not None and scenario.union_notice_date <= scenario.termination_notice_date),
        "no_wage_or_certificate_handover_condition": True,
        "no_post_hoc_reason_added": True,
    }
    return ReconstructionResult(
        case_id=scenario.case_id,
        status=status,
        fixed_termination_basis="《劳动合同法》第三十九条第一项：在试用期间被证明不符合录用条件",
        questions=questions[:3],
        risk_flags=risks,
        document_plan=_plan(scenario, can_generate),
        generated_documents=generated,
        consistency_checks=checks,
    )
