from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

try:
    from tools.generic_reconstruction_orchestrator import FIELD_LABELS, GenericReconstructionRequest, reconstruct_generic
    from tools.intake_question_engine import intake
    from tools.legal_fact_extractor_v1 import extract_guard_facts
    from tools.representative_legal_guard_v1 import evaluate_representative_legal_guard
except ModuleNotFoundError:
    from generic_reconstruction_orchestrator import FIELD_LABELS, GenericReconstructionRequest, reconstruct_generic
    from intake_question_engine import intake
    from legal_fact_extractor_v1 import extract_guard_facts
    from representative_legal_guard_v1 import evaluate_representative_legal_guard


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DialogueState(StrictModel):
    case_id: str
    turn_count: int = 0
    objective: str = ""
    facts: dict[str, Any] = Field(default_factory=dict)
    fact_sources: dict[str, list[str]] = Field(default_factory=dict)
    conflicts: list[dict[str, Any]] = Field(default_factory=list)
    candidate_document_ids: list[str] = Field(default_factory=list)
    selected_document_ids: list[str] = Field(default_factory=list)
    confirmed_preconditions: list[str] = Field(default_factory=list)
    confirmed_evidence_requirements: list[str] = Field(default_factory=list)
    not_applicable_fields: list[str] = Field(default_factory=list)
    stop_node_hits: list[str] = Field(default_factory=list)
    local_rules_checked: bool = False
    pending_questions: list[str] = Field(default_factory=list)
    last_status: str = "routing"


class DialogueRequest(StrictModel):
    case_id: str
    message: str = Field(min_length=1)
    state: DialogueState | None = None
    objective: str = ""
    fact_updates: dict[str, Any] = Field(default_factory=dict)
    selected_document_ids: list[str] = Field(default_factory=list, max_length=5)
    confirmed_preconditions: list[str] = Field(default_factory=list)
    confirmed_evidence_requirements: list[str] = Field(default_factory=list)
    not_applicable_fields: list[str] = Field(default_factory=list)
    stop_node_hits: list[str] = Field(default_factory=list)
    local_rules_checked: bool | None = None


class DialogueResult(StrictModel):
    case_id: str
    status: Literal[
        "routing", "needs_information", "blocked", "reroute", "draft_ready_with_review", "ready_for_drafting"
    ]
    drafting_allowed: bool
    questions: list[str]
    candidate_document_ids: list[str]
    selected_document_ids: list[str]
    extracted_this_turn: dict[str, Any]
    extraction_records_this_turn: list[dict[str, Any]]
    conflicts: list[dict[str, Any]]
    legal_guard_findings: list[dict[str, Any]]
    reconstruction_result: dict[str, Any] | None
    state: DialogueState
    final_notice: str


def _unique(items: list[str]) -> list[str]:
    return list(dict.fromkeys(item for item in items if item))


def _is_correction(message: str) -> bool:
    compact = "".join(message.split())
    return any(word in compact for word in ("更正", "改为", "以此为准", "以这个为准", "准确是", "实际是", "经核实"))


def _explicit_document_id(message: str) -> str | None:
    match = re.search(r"(?<![A-Z0-9])([RF]\d{1,3})(?!\d)", message.upper())
    return match.group(1) if match else None


def _conflict_question(conflict: dict[str, Any]) -> str:
    label = FIELD_LABELS.get(conflict["field"], conflict["field"])
    return f"前后关于{label}的信息不一致：此前为“{conflict['prior_value']}”，本轮为“{conflict['new_value']}”。请确认以哪个为准。"


def _merge_facts(
    state: DialogueState,
    extracted: dict[str, Any],
    records: list[dict[str, Any]],
    confirmed_updates: dict[str, Any],
    correction: bool,
) -> None:
    source_by_field = {item["field"]: item["source_text"] for item in records}
    conflicts = {item["field"]: item for item in state.conflicts}
    for field, value in extracted.items():
        source = source_by_field.get(field, "本轮自动提取")
        if field not in state.facts or state.facts[field] == value:
            state.facts[field] = value
            state.fact_sources[field] = _unique(state.fact_sources.get(field, []) + [source])
            continue
        if correction:
            state.facts[field] = value
            state.fact_sources[field] = [source]
            conflicts.pop(field, None)
            continue
        conflicts[field] = {
            "field": field,
            "prior_value": state.facts.pop(field),
            "new_value": value,
            "prior_source": state.fact_sources.pop(field, []),
            "new_source": source,
        }
    for field, value in confirmed_updates.items():
        state.facts[field] = value
        state.fact_sources[field] = ["本轮人工确认"]
        conflicts.pop(field, None)
    state.conflicts = list(conflicts.values())


def advance_dialogue(
    request: DialogueRequest,
    documents: dict[str, dict],
    capability_by_id: dict[str, dict],
) -> DialogueResult:
    if request.state and request.state.case_id != request.case_id:
        raise ValueError("state.case_id与本轮case_id不一致。")
    state = request.state.model_copy(deep=True) if request.state else DialogueState(case_id=request.case_id)
    state.turn_count += 1
    if request.objective.strip():
        state.objective = request.objective.strip()
    elif not state.objective:
        state.objective = request.message.strip()

    extraction = extract_guard_facts(request.message)
    _merge_facts(state, extraction["facts"], extraction["records"], request.fact_updates, _is_correction(request.message))

    intake_result = intake(request.message, documents)
    latest_candidates = [item.document_id for item in intake_result.candidate_documents]
    state.candidate_document_ids = _unique(
        latest_candidates + extraction["relevant_document_ids"] + state.candidate_document_ids
    )[:5]
    explicit_id = _explicit_document_id(request.message)
    if request.selected_document_ids:
        state.selected_document_ids = _unique(request.selected_document_ids)
    elif explicit_id in capability_by_id:
        state.selected_document_ids = [explicit_id]
    elif intake_result.mode == "direct" and latest_candidates:
        state.selected_document_ids = [latest_candidates[0]]

    state.confirmed_preconditions = _unique(state.confirmed_preconditions + request.confirmed_preconditions)
    state.confirmed_evidence_requirements = _unique(
        state.confirmed_evidence_requirements + request.confirmed_evidence_requirements
    )
    state.not_applicable_fields = _unique(state.not_applicable_fields + request.not_applicable_fields)
    state.stop_node_hits = _unique(state.stop_node_hits + request.stop_node_hits)
    if request.local_rules_checked is not None:
        state.local_rules_checked = request.local_rules_checked

    conflict_questions = [_conflict_question(item) for item in state.conflicts]
    reconstruction = None
    guard_findings: list[dict[str, Any]] = []
    drafting_allowed = False
    if state.selected_document_ids:
        composed = reconstruct_generic(
            GenericReconstructionRequest(
                case_id=state.case_id,
                objective=state.objective or request.message,
                selected_document_ids=state.selected_document_ids,
                facts=state.facts,
                not_applicable_fields=state.not_applicable_fields,
                confirmed_preconditions=state.confirmed_preconditions,
                confirmed_evidence_requirements=state.confirmed_evidence_requirements,
                stop_node_hits=state.stop_node_hits,
                local_rules_checked=state.local_rules_checked,
            ),
            capability_by_id,
        )
        reconstruction = composed.model_dump(mode="json")
        guard_findings = composed.legal_guard_findings
        status = composed.status
        drafting_allowed = composed.drafting_allowed
        questions = _unique(conflict_questions + composed.questions)[:3]
    else:
        guard_ids = _unique(state.candidate_document_ids + extraction["relevant_document_ids"])
        findings = evaluate_representative_legal_guard(guard_ids, state.facts)
        guard_findings = [item.to_dict() for item in findings]
        if state.conflicts:
            status = "needs_information"
        elif any(item.outcome == "blocked" for item in findings):
            status = "blocked"
        elif any(item.outcome == "reroute" for item in findings):
            status = "reroute"
        elif any(item.outcome == "needs_information" for item in findings):
            status = "needs_information"
        else:
            status = "routing"
        guard_questions = [question for item in findings for question in item.questions]
        fallback_questions = intake_result.questions if intake_result.mode != "fallback" else state.pending_questions
        questions = _unique(conflict_questions + guard_questions + fallback_questions)[:3]

    state.pending_questions = questions
    state.last_status = status
    return DialogueResult(
        case_id=state.case_id,
        status=status,
        drafting_allowed=drafting_allowed,
        questions=questions,
        candidate_document_ids=state.candidate_document_ids,
        selected_document_ids=state.selected_document_ids,
        extracted_this_turn=extraction["facts"],
        extraction_records_this_turn=extraction["records"],
        conflicts=state.conflicts,
        legal_guard_findings=guard_findings,
        reconstruction_result=reconstruction,
        state=state,
        final_notice="本方案用于完善事实、证据和程序记录，可降低争议风险，但不能替代对个案事实、当地规则和裁判尺度的核验。",
    )
