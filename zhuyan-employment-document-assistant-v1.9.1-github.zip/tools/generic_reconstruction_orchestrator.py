from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class GenericReconstructionRequest(StrictModel):
    case_id: str
    objective: str
    user_query: str = ""
    selected_document_ids: list[str] = Field(min_length=1, max_length=5)
    facts: dict[str, Any]
    not_applicable_fields: list[str] = Field(default_factory=list)
    confirmed_preconditions: list[str] = Field(default_factory=list)
    confirmed_evidence_requirements: list[str] = Field(default_factory=list)
    stop_node_hits: list[str] = Field(default_factory=list)
    local_rules_checked: bool = False


class DocumentPlanItem(StrictModel):
    document_id: str
    title: str
    action: Literal["generate_now", "needs_facts", "blocked"]
    risk_level: str
    calibration_level: str
    generation_mode: str
    reason: str


class DraftingBrief(StrictModel):
    document_id: str
    title: str
    generation_mode: str
    modules: list[str]
    applicable_facts: dict[str, Any]
    evidence_requirements: list[str]
    guard: str
    mandatory_constraints: list[str]


class GenericReconstructionResult(StrictModel):
    case_id: str
    status: Literal["blocked", "needs_information", "draft_ready_with_review", "ready_for_drafting"]
    drafting_allowed: bool
    risk_level: str
    questions: list[str]
    remaining_missing_count: int
    missing_fields: list[str]
    unconfirmed_preconditions: list[str]
    evidence_gaps: list[str]
    stop_reasons: list[str]
    legal_guard_findings: list[dict[str, Any]]
    extracted_guard_facts: dict[str, Any]
    fact_extraction_records: list[dict[str, Any]]
    fact_summary: dict[str, Any]
    document_plan: list[DocumentPlanItem]
    drafting_briefs: list[DraftingBrief]
    candidate_related_documents: list[dict]
    execution_steps: list[str]
    final_notice: str


FIELD_LABELS = {
    "employer_name": "用人单位名称",
    "employee_name": "员工姓名",
    "locality": "劳动合同履行地及适用地区",
    "case_objective": "企业希望实现的具体结果",
    "event_or_effective_date": "关键事件或拟生效日期",
    "party_identity": "各方主体、身份和签署权限",
    "agreement_purpose": "协议目的和真实安排",
    "rights_and_obligations": "双方具体权利义务",
    "term": "协议或义务期限",
    "amount_or_consideration": "金额、补偿或其他对价",
    "signing_date": "实际签署日期",
    "decision_basis": "拟作出决定的事实和规则依据",
    "fact_summary": "支持文书的关键事实",
    "notice_date": "拟签发通知日期",
    "effective_date": "决定或安排生效日期",
    "delivery_method": "拟采用的送达方式及证据",
    "fixed_legal_route": "固定且唯一的法律处理路线",
    "event_time": "事件发生时间",
    "specific_conduct": "具体行为及发生经过",
    "rule_basis": "适用制度或合同条款",
    "rule_publication": "制度民主程序、公示或签收情况",
    "investigation_record": "调查核验过程",
    "employee_defense": "员工陈述申辩",
    "union_status": "工会建立及履行程序情况",
    "delivery": "送达安排和证据",
    "business_change": "经营或组织变化的具体事实",
    "affected_headcount": "拟影响人数",
    "workforce_total": "企业职工总数",
    "contract_performance_impact": "变化为何导致原合同无法继续履行",
    "consultation": "协商变更及意见听取情况",
    "protected_employees": "限制解除或优先留用人员筛查",
    "reporting_status": "依法报告或通知程序状态",
    "protected_information": "需要保护的具体信息和秘密点",
    "employee_role": "员工岗位及接触信息范围",
    "access_scope": "系统、资料和客户资源访问范围",
    "restriction_scope": "竞业限制业务范围",
    "restriction_term": "竞业限制期限",
    "restriction_area": "竞业限制地域",
    "compensation": "竞业补偿标准和支付方式",
    "breach_evidence": "履约或违约证据安排",
    "insurance_location": "参保地和经办机构",
    "current_insurance_status": "当前参保状态",
    "employee_objection": "员工异议的真实内容",
    "agency_feedback": "经办机构受理或答复",
    "historical_unpaid_period": "历史未缴期间",
    "historical_allowance": "历史社保补贴或相关付款",
    "remediation_status": "补缴、更正或整改进度",
    "position_requirements": "岗位职责和任职要求",
    "preexisting_standard": "处理前已经明确的考核标准",
    "first_assessment": "首次考核事实和结果",
    "support_or_training": "已经实施的辅导或培训",
    "transfer_details": "调岗方案和实际履行情况",
    "second_assessment": "再次考核事实和结果",
    "employee_response": "员工意见及公司核验情况",
    "first_incompetence": "首次不能胜任的具体判断",
    "training_or_transfer": "培训或调岗的实际实施情况",
    "observation_period": "合理观察期间",
    "second_incompetence": "再次不能胜任的具体判断",
    "protected_status_check": "限制解除和特殊保护情形核验",
    "notice_option": "提前通知或代通知金方案",
    "compensation_calculation": "经济补偿核算",
    "employment_status": "劳动关系和在职状态",
    "insured_period": "参保期间",
    "contribution_base": "社会保险缴费基数",
    "payment_status": "申报和缴费状态",
    "injury_or_medical_status": "工伤、医疗及待遇办理状态",
    "event_facts": "事项经过和具体工作内容",
    "participants": "参与人员及职责",
    "record_date": "记录形成日期",
    "supporting_materials": "支持材料",
    "pay_components": "工资和补偿项目",
    "calculation_period": "核算期间",
    "attendance_data": "考勤及实际工作数据",
    "working_time_system": "适用工时制度",
    "leave_entitlement": "调休或休假安排",
    "payment_records": "支付和结算记录",
    "tax_and_social_declarations": "个税和社会保险申报情况",
    "governance_subject": "民主程序实施主体",
    "representative_selection": "职工代表产生和资格情况",
    "meeting_notice": "会议通知和议题送达",
    "attendance": "参会和签到情况",
    "discussion_and_vote": "讨论和表决过程",
    "union_consultation": "与工会平等协商情况",
    "publication": "制度版本固定和公示情况",
    "work_content": "工作内容和岗位职责",
    "work_location": "工作地点",
    "rest_leave": "工作时间和休息休假安排",
    "salary_structure": "劳动报酬构成和核算方式",
    "payday": "工资支付周期和日期",
    "social_insurance": "社会保险办理和个人部分代扣安排",
    "labor_protection": "劳动条件、劳动保护和职业危害防护",
    "probation_terms": "试用期约定及适用条件",
    "contract_copy_receipt": "劳动合同文本交付和签收情况",
    "offer_position": "拟录用岗位",
    "offer_work_location": "拟定工作地点",
    "employment_start": "实际用工或拟报到日期",
    "contract_term": "拟订劳动合同期限",
    "offer_conditions": "录用通知生效和录用前提条件",
    "acceptance_deadline": "接受录用通知的期限和方式",
    "report_requirements": "报到材料和办理要求",
    "revocation_boundary": "变更、撤回及缔约责任边界",
    "assessment_cycle": "考核周期",
    "performance_metrics": "绩效指标、目标值和计算口径",
    "metric_weights": "指标权重",
    "data_sources": "考核数据来源和取数规则",
    "scoring_rules": "评分、扣分和合格规则",
    "support_resources": "公司提供的资源、培训和支持",
    "review_and_appeal": "结果反馈、异议和复核程序",
    "performance_consequences": "考核结果的管理后果及法律边界",
    "job_adjustment_reason": "调岗所依据的不能胜任事实",
    "new_position": "调整后的岗位和职责",
    "adjustment_scope": "工作地点、汇报关系和其他调整范围",
    "salary_change_route": "薪酬是否变化及其协商或制度依据",
    "assessment_standard_after_transfer": "新岗位观察期和再次考核标准",
    "activation_mechanism": "离职竞业限制启动机制",
    "waiver_or_termination": "竞业限制不启动、解除或终止安排",
    "breach_consequence": "违约责任及合理性调整规则",
    "overtime_date_type": "加班日期性质",
    "overtime_start_end": "加班起止时间和实际时数",
    "approval_status": "加班安排或审批状态",
    "statutory_compensation": "依法支付加班工资或安排补休的方式",
    "termination_initiator": "工伤劳动关系终止或解除的发起人及事由",
    "injury_grade": "劳动能力鉴定等级和生效情况",
    "benefit_items": "工伤待遇项目及支付主体",
    "local_benefit_basis": "当地一次性待遇计算基数和月数",
    "retirement_distance": "距法定退休年龄及就业补助递减因素",
    "payment_schedule": "各项目核定、支付和到账安排",
    "rights_reservation": "尚未核定或支付项目的权利保留",
    "average_monthly_wage": "解除前十二个月平均工资及计算口径",
    "service_years": "本单位工作年限和补偿年限",
    "actual_secret_access": "员工是否实际知悉、接触商业秘密或知识产权相关保密事项",
    "probation_months": "拟约定试用期月数",
    "contract_term_months": "劳动合同期限月数",
    "account_list": "自媒体账号、平台、名称及账号ID清单",
    "phone_device_arrangement": "注册手机号、设备和费用承担安排",
    "content_ownership": "运营内容、素材和成果归属",
    "account_control": "账号后台、密码和验证方式控制安排",
    "transfer_duties": "调岗、离职或停止运营时的交接义务",
}

RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}
NON_WAIVABLE_FIELDS = {
    "employer_name",
    "locality",
    "case_objective",
    "event_or_effective_date",
}


def _filled(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict, tuple, set)):
        return bool(value)
    return True


def _question_for_field(field_id: str) -> str:
    label = FIELD_LABELS.get(field_id, field_id)
    return f"请补充{label}；如确实不适用，请明确说明原因。"


def _placeholder_for_field(field_id: str) -> str:
    choices = {
        "term": "【请选择：固定期限____年／无固定期限／以完成一定工作任务为期限】",
        "contract_term": "【请选择：固定期限____年／无固定期限／以完成一定工作任务为期限】",
        "working_time_system": "【请选择：标准工时制／经批准的综合计算工时制／经批准的不定时工作制】",
        "delivery_method": "【请选择：当面签收／EMS邮寄／双方确认的电子方式】",
        "notice_option": "【请选择：提前30日书面通知／额外支付一个月工资】",
    }
    return choices.get(field_id, f"【请填写：{FIELD_LABELS.get(field_id, field_id)}】")


def _risk(cards: list[dict]) -> str:
    return max((card["risk_level"] for card in cards), key=lambda item: RISK_ORDER[item])


def reconstruct_generic(request: GenericReconstructionRequest, capability_by_id: dict[str, dict]) -> GenericReconstructionResult:
    try:
        from tools.representative_legal_guard_v1 import evaluate_representative_legal_guard
    except ModuleNotFoundError:
        from representative_legal_guard_v1 import evaluate_representative_legal_guard
    try:
        from tools.legal_fact_extractor_v1 import extract_guard_facts
    except ModuleNotFoundError:
        from legal_fact_extractor_v1 import extract_guard_facts

    if len(request.selected_document_ids) != len(set(request.selected_document_ids)):
        raise ValueError("文书编号不得重复。")
    unknown = [item for item in request.selected_document_ids if item not in capability_by_id]
    if unknown:
        raise ValueError(f"未知文书编号：{','.join(unknown)}")
    cards = [capability_by_id[item] for item in request.selected_document_ids]
    required_fields = list(dict.fromkeys(field for card in cards for field in card["required_fields"]))
    missing_fields = [
        field for field in required_fields
        if (field in NON_WAIVABLE_FIELDS or field not in request.not_applicable_fields)
        and not _filled(request.facts.get(field))
    ]
    all_preconditions = list(dict.fromkeys(item for card in cards for item in card["preconditions"]))
    unconfirmed_preconditions = [item for item in all_preconditions if item not in request.confirmed_preconditions]
    all_evidence = list(dict.fromkeys(item for card in cards for item in card["evidence_requirements"]))
    evidence_gaps = [item for item in all_evidence if item not in request.confirmed_evidence_requirements]
    known_stop_nodes = {item for card in cards for item in card["stop_nodes"]}
    stop_reasons = list(dict.fromkeys(request.stop_node_hits))
    if any(item not in known_stop_nodes for item in stop_reasons):
        stop_reasons.append("存在能力卡以外的个案停止事项，需专项核验。")
    extraction = extract_guard_facts(request.user_query) if request.user_query.strip() else {
        "facts": {}, "records": [], "relevant_document_ids": []
    }
    guard_facts = {**extraction["facts"], **request.facts}
    legal_findings = evaluate_representative_legal_guard(request.selected_document_ids, guard_facts)
    blocking_findings = [item for item in legal_findings if item.outcome in {"blocked", "reroute"}]
    guard_information_findings = [item for item in legal_findings if item.outcome == "needs_information"]
    stop_reasons.extend(item.reason for item in blocking_findings if item.reason not in stop_reasons)

    missing_items = [f"field:{item}" for item in missing_fields]
    missing_items += [f"precondition:{item}" for item in unconfirmed_preconditions]
    missing_items += [f"evidence:{item}" for item in evidence_gaps]
    questions = []
    if missing_items or legal_findings:
        questions.append("如需我把文书中的留空项补齐并进一步优化，请补充公司和员工信息、关键日期、金额及已经发生的核心事实；暂不补充也可先使用当前草稿。")

    overall_risk = _risk(cards)
    if missing_items or stop_reasons or guard_information_findings or overall_risk in {"high", "critical"} or not request.local_rules_checked or any(
        card["calibration"]["level"] != "legal_reviewed" for card in cards
    ):
        status = "draft_ready_with_review"
    else:
        status = "ready_for_drafting"
    drafting_allowed = True

    plan = []
    briefs = []
    for card in cards:
        action = "generate_now"
        reason = "立即生成首份文书；缺失事实使用占位符，风险和待核验事项置于文书之后。"
        plan.append(
            DocumentPlanItem(
                document_id=card["document_id"],
                title=card["title"],
                action=action,
                risk_level=card["risk_level"],
                calibration_level=card["calibration"]["level"],
                generation_mode=card["generation_mode"],
                reason=reason,
            )
        )
        applicable = {
            field: guard_facts[field] if _filled(guard_facts.get(field)) else _placeholder_for_field(field)
            for field in card["required_fields"]
        }
        applicable.update({key: value for key, value in guard_facts.items() if _filled(value)})
        briefs.append(
            DraftingBrief(
                document_id=card["document_id"],
                title=card["title"],
                generation_mode=card["generation_mode"],
                modules=card["modules"],
                applicable_facts=applicable,
                evidence_requirements=card["evidence_requirements"],
                guard=card["guard"],
                mandatory_constraints=card["stop_nodes"] + [
                    "缺失信息用清晰占位符或常用选项保留，不得因此拒绝生成。",
                    "只把用户已经提供的内容写成既有事实，不补造签字、日期、证据或历史材料。",
                    "用户要求的高风险安排可先形成可审阅草稿，但必须在文书后提示风险和合规替代方案。",
                    "同一案件中的主体、日期、金额、理由和证据名称必须一致。",
                ],
            )
        )

    related = []
    selected = set(request.selected_document_ids)
    for card in cards:
        for relation in card["related_documents"]:
            if relation["target_id"] not in selected:
                related.append({"source_id": card["document_id"], **relation})
    related = list({(item["source_id"], item["target_id"], item["relation_type"]): item for item in related}.values())

    steps = []
    steps.append("先交付首份完整文书；缺失信息保留占位符或常用选项，不以追问阻塞交付。")
    if missing_fields or guard_information_findings:
        steps.append("文书后用一个简单问题邀请用户补充关键信息，以便生成更完整版本。")
    if unconfirmed_preconditions:
        steps.append("核验前置程序并固定形成时间、参与人员及支持材料。")
    if evidence_gaps:
        steps.append("核验原件、数据来源和形成时间，将证据逐项对应到正文事实。")
    if drafting_allowed:
        steps += [
            "根据drafting_briefs逐份重写文书，不照抄范文正文。",
            "完成跨文书主体、日期、金额、处理理由和证据名称一致性检查。",
            "签署或送达前复核当地规则、裁判尺度及个案高风险节点。",
        ]
    if stop_reasons:
        steps.append("在文书之后明确提示已命中的真实性、程序或时点风险，并给出合规替代方案。")
    for finding in legal_findings:
        if finding.action not in steps:
            steps.append(finding.action)

    return GenericReconstructionResult(
        case_id=request.case_id,
        status=status,
        drafting_allowed=drafting_allowed,
        risk_level=overall_risk,
        questions=questions,
        remaining_missing_count=len(missing_items) + len(guard_information_findings),
        missing_fields=missing_fields,
        unconfirmed_preconditions=unconfirmed_preconditions,
        evidence_gaps=evidence_gaps,
        stop_reasons=stop_reasons,
        legal_guard_findings=[item.to_dict() for item in legal_findings],
        extracted_guard_facts=extraction["facts"],
        fact_extraction_records=extraction["records"],
        fact_summary={key: value for key, value in request.facts.items() if _filled(value)},
        document_plan=plan,
        drafting_briefs=briefs,
        candidate_related_documents=related,
        execution_steps=steps,
        final_notice="本方案用于完善事实、证据和程序记录，可降低争议风险，但不能替代对个案事实、当地规则和裁判尺度的核验。",
    )
