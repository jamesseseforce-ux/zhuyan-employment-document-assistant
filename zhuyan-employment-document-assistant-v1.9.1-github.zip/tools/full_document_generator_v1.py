from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

try:
    from tools.generic_reconstruction_orchestrator import (
        FIELD_LABELS,
        GenericReconstructionRequest,
        GenericReconstructionResult,
        reconstruct_generic,
    )
except ModuleNotFoundError:
    from generic_reconstruction_orchestrator import (
        FIELD_LABELS,
        GenericReconstructionRequest,
        GenericReconstructionResult,
        reconstruct_generic,
    )


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FullDocument(StrictModel):
    document_id: str
    title: str
    generation_mode: str
    profile_level: Literal["representative_specialized_v1", "generic_mode_v1"]
    content: str
    source_fact_fields: list[str]
    evidence_requirements: list[str]
    review_required: bool


class FullDraftResult(StrictModel):
    case_id: str
    status: str
    drafting_allowed: bool
    questions: list[str]
    stop_reasons: list[str]
    legal_guard_findings: list[dict[str, Any]]
    extracted_guard_facts: dict[str, Any]
    fact_extraction_records: list[dict[str, Any]]
    documents: list[FullDocument]
    candidate_related_documents: list[dict]
    review_notice: str
    post_document_notes: list[str]


SPECIALIZED_SECTIONS: dict[str, list[tuple[str, list[str]]]] = {
    "R3": [
        ("拟录用岗位和劳动条件", ["employee_name", "offer_position", "offer_work_location", "salary_structure"]),
        ("报到、合同期限和试用期", ["employment_start", "contract_term", "probation_terms", "report_requirements"]),
        ("录用通知生效条件", ["offer_conditions", "decision_basis"]),
        ("接受、变更和撤回", ["acceptance_deadline", "revocation_boundary"]),
        ("签发与送达", ["notice_date", "effective_date", "delivery_method"]),
    ],
    "R8": [
        ("合同主体与订立目的", ["party_identity", "agreement_purpose"]),
        ("合同期限和试用期", ["term", "probation_terms", "event_or_effective_date"]),
        ("工作内容和工作地点", ["work_content", "work_location"]),
        ("工作时间和休息休假", ["working_time_system", "rest_leave"]),
        ("劳动报酬", ["salary_structure", "amount_or_consideration", "payday"]),
        ("试用期录用条件和销售岗位考核", ["position_requirements", "performance_metrics", "data_sources", "scoring_rules", "support_resources", "review_and_appeal", "performance_consequences"]),
        ("社会保险", ["social_insurance"]),
        ("劳动条件、保护和职业危害防护", ["labor_protection"]),
        ("双方权利义务及变更解除", ["rights_and_obligations"]),
        ("合同文本、争议处理和签署", ["contract_copy_receipt", "locality", "signing_date"]),
    ],
    "R71": [
        ("岗位职责和考核周期", ["position_requirements", "assessment_cycle"]),
        ("指标、目标值和权重", ["performance_metrics", "metric_weights"]),
        ("数据来源和评分规则", ["data_sources", "scoring_rules"]),
        ("资源支持和过程反馈", ["support_resources"]),
        ("结果确认、异议和复核", ["review_and_appeal"]),
        ("考核结果的管理后果", ["performance_consequences"]),
    ],
    "F22": [
        ("决定依据和处理边界", ["decision_basis", "case_objective"]),
        ("原岗位要求及首次考核事实", ["position_requirements", "preexisting_standard", "first_assessment", "job_adjustment_reason"]),
        ("员工意见及公司支持", ["employee_response", "support_or_training"]),
        ("岗位调整安排", ["new_position", "transfer_details", "adjustment_scope", "effective_date"]),
        ("薪酬处理边界", ["salary_change_route"]),
        ("后续观察和考核", ["observation_period", "assessment_standard_after_transfer", "delivery_method"]),
    ],
    "F57": [
        ("固定处理路线", ["fixed_legal_route", "decision_basis"]),
        ("已经查明的具体事实", ["event_time", "specific_conduct", "fact_summary"]),
        ("制度依据及履行程序", ["rule_basis", "rule_publication", "publication"]),
        ("调查和申辩", ["investigation_record", "employee_defense"]),
        ("民主程序与工会程序", ["governance_subject", "representative_selection", "meeting_notice", "attendance", "discussion_and_vote", "union_consultation", "union_status"]),
        ("解除决定及送达", ["effective_date", "delivery_method", "delivery"]),
    ],
    "F58": [
        ("固定解除路线", ["fixed_legal_route", "decision_basis"]),
        ("首次不能胜任事实", ["position_requirements", "preexisting_standard", "first_assessment", "first_incompetence"]),
        ("真实培训或调岗", ["support_or_training", "transfer_details", "training_or_transfer", "observation_period"]),
        ("再次不能胜任事实", ["second_assessment", "second_incompetence", "employee_response"]),
        ("限制解除情形及程序", ["protected_status_check", "union_status", "rule_publication"]),
        ("通知方式与经济补偿", ["employment_start", "average_monthly_wage", "service_years", "notice_option", "compensation_calculation", "effective_date", "delivery_method", "delivery"]),
    ],
    "F60": [
        ("固定处理路线", ["fixed_legal_route", "decision_basis"]),
        ("客观情况重大变化", ["business_change", "event_time", "fact_summary"]),
        ("对劳动合同履行的影响", ["contract_performance_impact", "affected_headcount", "workforce_total"]),
        ("协商变更过程", ["consultation", "employee_response"]),
        ("人员保护与程序核验", ["protected_employees", "union_status", "reporting_status"]),
        ("解除、补偿与送达", ["employment_start", "average_monthly_wage", "service_years", "notice_option", "compensation_calculation", "effective_date", "delivery_method", "delivery"]),
    ],
    "R42": [
        ("主体、岗位与保护目的", ["party_identity", "employee_role", "agreement_purpose"]),
        ("受保护信息和接触范围", ["protected_information", "access_scope"]),
        ("离职后竞业限制范围", ["restriction_scope", "restriction_area", "restriction_term"]),
        ("竞业补偿", ["compensation", "amount_or_consideration"]),
        ("启动、不启动和解除", ["activation_mechanism", "waiver_or_termination"]),
        ("履约报告、核验和违约责任", ["breach_evidence", "rights_and_obligations", "breach_consequence"]),
        ("期限与签署", ["term", "signing_date"]),
    ],
    "R60": [
        ("申请人与加班事项", ["employee_name", "event_facts", "participants", "overtime_start_end"]),
        ("日期性质、工时制度及审批", ["overtime_date_type", "working_time_system", "approval_status", "attendance_data", "record_date"]),
        ("法定补偿安排", ["statutory_compensation", "pay_components", "calculation_period", "leave_entitlement"]),
        ("支持材料与核对", ["supporting_materials", "payment_records", "tax_and_social_declarations"]),
    ],
    "R68": [
        ("办理依据和整改目标", ["decision_basis", "case_objective"]),
        ("劳动关系及参保现状", ["employment_status", "actual_employer", "insurance_location", "current_insurance_status"]),
        ("参保期间、基数和缴费情况", ["insured_period", "contribution_base", "payment_status"]),
        ("员工异议和经办反馈", ["employee_objection", "agency_feedback"]),
        ("历史未缴情形核对", ["historical_unpaid_period", "historical_allowance"]),
        ("整改及后续办理", ["remediation_status", "injury_or_medical_status", "effective_date"]),
    ],
    "R92": [
        ("主体、工伤及劳动关系", ["party_identity", "employment_status", "injury_or_medical_status", "injury_grade"]),
        ("劳动关系终止条件", ["termination_initiator", "retirement_distance"]),
        ("参保和经办情况", ["insurance_location", "insured_period", "contribution_base", "payment_status", "agency_feedback"]),
        ("待遇项目、支付主体和计算", ["benefit_items", "local_benefit_basis", "amount_or_consideration", "rights_and_obligations"]),
        ("核定、支付和权利保留", ["payment_schedule", "rights_reservation"]),
        ("终止安排与履行期限", ["agreement_purpose", "term", "event_or_effective_date"]),
        ("签署和文本", ["signing_date", "locality"]),
    ],
    "X001": [
        ("协议主体与适用账号", ["employer_name", "employee_name", "account_list"]),
        ("手机号、设备与费用", ["phone_device_arrangement"]),
        ("账号注册、控制和验证", ["account_control"]),
        ("内容制作、发布与成果归属", ["content_ownership"]),
        ("数据安全和禁止行为", ["rights_and_obligations"]),
        ("调岗、离职和停止运营时的交接", ["transfer_duties", "event_or_effective_date"]),
        ("违约、争议和签署", ["locality", "signing_date"]),
    ],
}


MODE_SECTIONS = {
    "agreement": [
        ("主体与目的", ["party_identity", "agreement_purpose"]),
        ("权利义务", ["rights_and_obligations"]),
        ("期限、金额与履行", ["term", "amount_or_consideration", "event_or_effective_date"]),
        ("违约、争议与签署", ["locality", "signing_date"]),
    ],
    "notice": [
        ("通知对象和事实", ["employee_name", "fact_summary"]),
        ("决定依据", ["decision_basis", "fixed_legal_route"]),
        ("通知事项", ["case_objective", "effective_date"]),
        ("签发与送达", ["notice_date", "delivery_method", "delivery"]),
    ],
    "record": [
        ("记录对象", ["employee_name", "participants"]),
        ("事项经过", ["event_facts", "fact_summary"]),
        ("陈述和核对", ["employee_response", "supporting_materials"]),
        ("形成和签署", ["record_date", "signing_date"]),
    ],
    "policy": [
        ("目的和适用范围", ["agreement_purpose", "case_objective"]),
        ("管理规则", ["rights_and_obligations", "rule_basis"]),
        ("执行、监督和处理", ["decision_basis", "effective_date"]),
        ("民主程序、公示和生效", ["rule_publication", "publication", "event_or_effective_date"]),
    ],
    "litigation": [
        ("当事人与请求", ["party_identity", "case_objective"]),
        ("事实和争议焦点", ["fact_summary", "specific_conduct"]),
        ("依据和论证", ["decision_basis", "rule_basis"]),
        ("证据、程序和提交", ["investigation_record", "supporting_materials", "signing_date"]),
    ],
}


STATIC_CLAUSES = {
    "R3": [
        "录用通知用于确认后续订立劳动合同的主要安排；劳动关系自实际用工之日起建立。通知内容已经具体并被候选人接受的，任何一方变更或撤回均应遵守诚信原则并考虑对方已经产生的合理信赖。",
        "背景调查、资格证书等附条件事项必须具体、必要且能够客观核验，不得把与岗位无关的歧视性条件或由公司任意解释的条件作为撤回录用的依据。",
    ],
    "R8": [
        "双方确认：劳动合同的履行、变更、解除和终止依照法律法规及依法有效的集体合同、规章制度执行；任何一方均不得以本合同排除对方依法享有的权利。",
        "发生劳动争议时，双方可先行协商；协商不成的，依法向有管辖权的劳动人事争议仲裁机构申请仲裁。",
        "本合同一式两份，双方各执一份；用人单位应将已签署文本实际交付劳动者，并保留真实签收记录。",
    ],
    "R42": [
        "保密义务、在职忠实义务与离职后竞业限制分别适用；竞业限制仅针对协议载明且确有保护必要的业务、地域和期限，不当然限制与受保护业务无关的就业。",
        "公司应按约持续支付竞业补偿；启动、履行、解除及违约责任均以实际通知、支付、就业活动和合法取得的证据为准。",
    ],
    "R71": [
        "考核指标应当在考核周期开始前明确，数据来源、权重和评分方式不得在结果形成后单方变更。员工对数据或评分提出异议时，应记录具体异议并完成复核。",
        "一次考核不达标、末位排名或未签字本身不当然等同于不能胜任、严重违纪或具备解除条件；后续管理措施仍须结合真实事实和相应法定程序另行判断。",
    ],
    "F22": [
        "本通知只处理基于首次不能胜任事实的合理岗位调整。调岗应与员工能力、原合同约定、经营需要和实际履行条件相匹配，不得借调岗实施侮辱性、惩罚性或明显不合理安排。",
        "岗位调整不当然授权公司单方降低劳动报酬。薪酬变化应优先协商书面确认；主张依据既有薪酬制度随岗调整的，须另行核验制度效力、合同约定、合理性及对员工基本生活和既得工资的影响。",
    ],
    "F57": [
        "本次解除只能以通知书载明且在解除时已经存在的事实、制度和证据为依据，争议发生后不得新增或替换解除理由。已建立工会的，应在作出解除决定前将理由通知工会并研究其意见。",
        "解除不影响截至解除日工资、依法应付项目、解除证明以及档案和社会保险关系转移手续的办理，交接不得作为拒绝履行法定义务的条件。",
    ],
    "F58": [
        "本次解除以首次不能胜任、真实培训或合理调岗、合理观察期及再次不能胜任形成连续证据链；末位排名、一次低分或临时改变标准不能替代上述事实。",
        "解除前应再次核验限制解除情形、工会程序及提前三十日书面通知或额外支付一个月工资的选择，并依法支付经济补偿、结清工资和办理解除后手续。",
    ],
    "F60": [
        "本路径要求客观变化与订立劳动合同时的基础直接相关，并已经导致原劳动合同无法履行；一般经营下降、管理便利或主观调整意愿不足以单独支持解除。",
        "公司应先就可行的合同变更方案进行真实、具体的协商。本案不得与经济性裁员程序混用；实际涉及人数、比例或处理范围变化时，应重新判断是否进入经济性裁员路径。",
    ],
    "R60": [
        "事前审批制度是内部管理和证据规则，不能当然否定公司已经安排、认可或者实际接受工作成果的加班事实。实际工作时间应结合审批、考勤、系统日志、工作成果和管理人员知情情况综合核对。",
        "标准工时制下，工作日延时应依法支付相应加班工资；休息日加班可以安排补休，不能安排补休的依法支付加班工资；法定休假日加班不得以补休替代法定加班工资。",
    ],
    "R68": [
        "依法参保和按时足额缴费是法定义务，员工声明、现金补贴、亲属代领或其他付款安排均不替代参保缴费。历史差额应以实际劳动关系、工资资料、申报记录和有权机构核定为准。",
        "补缴完成前不得写成已经补缴或争议已经清结；补缴后涉及既往社保补偿款返还的，应逐笔核对付款性质、期间和司法解释规定，不作概括抵销。",
    ],
    "R92": [
        "工伤保险基金支付项目与用人单位依法承担项目应分别列明，未实际核定或支付的待遇不得写成已经结清。",
        "本协议不以概括性放弃条款免除任何一方依法不能排除的责任；具体金额、付款主体和到账状态以经办机构核定及实际支付记录为准。",
        "七级至十级伤残劳动关系终止或解除须先核验法定触发方式；不得通过诱导个人辞职把本应由公司承担的违法解除风险转化为员工自愿离职。",
    ],
    "X001": [
        "本协议所称企业业务账号，是指以企业品牌、产品、业务或企业投入资源持续运营的账号。员工个人生活账号不因员工参与工作而当然转为企业资产；双方应按账号清单逐一确认性质。",
        "用于企业业务账号的手机号、邮箱、设备、后台权限、密码及双重验证方式，应登记在册并保持企业可控。员工不得擅自改绑、出售、出借、注销账号或设置企业无法恢复的验证方式。",
        "员工依岗位职责、企业指令或使用企业资源制作的脚本、图文、视频、素材、客户线索和运营数据，按本协议及法律规定确定使用和归属；涉及员工肖像、姓名、声音或个人账号的，应另行明确授权范围和期限。",
        "员工调岗、离职或停止运营时，应在指定期限内完成账号、设备、素材、数据、商务合作和未结事项交接。企业应形成书面交接清单并现场核验，不得以概括条款替代实际交接。",
    ],
}


CORE_FIELDS = ["employer_name", "locality", "case_objective", "event_or_effective_date"]


def _value_line(field: str, value: Any) -> str:
    label = FIELD_LABELS.get(field, field)
    if isinstance(value, list):
        rendered = "；".join(str(item) for item in value)
    elif isinstance(value, dict):
        rendered = "；".join(f"{key}：{item}" for key, item in value.items())
    else:
        rendered = str(value)
    return f"{label}：{rendered}。"


def _signature_block(mode: str, facts: dict[str, Any]) -> str:
    employer = str(facts.get("employer_name", "用人单位"))
    if mode == "agreement":
        return f"甲方（盖章）：{employer}\n乙方（签字）：见主体信息\n签署日期：{facts.get('signing_date', facts.get('event_or_effective_date'))}"
    if mode == "record":
        return "记录人（签字）：见参与人员信息\n员工或陈述人（签字）：见记录对象信息\n见证人（如有）：按实际填写"
    if mode == "litigation":
        return f"提交人（盖章）：{employer}\n签署日期：{facts.get('signing_date', facts.get('event_or_effective_date'))}"
    return f"发出单位（盖章）：{employer}\n授权签发人：按实际授权签署\n签发日期：{facts.get('notice_date', facts.get('event_or_effective_date'))}"


def _opening(mode: str, title: str, facts: dict[str, Any]) -> str:
    employer = str(facts.get("employer_name", "用人单位"))
    employee = facts.get("employee_name")
    if mode == "notice":
        recipient = f"致：{employee}" if employee else "致：相关人员"
        return f"{recipient}\n\n{employer}根据已经核验的个案事实和现有材料，就下列事项作出本书面通知。"
    if mode == "agreement":
        return "各方在确认主体身份、真实安排和已披露事实的基础上，经协商形成如下条款。"
    if mode == "record":
        return "本记录用于如实固定当时发生的事项、参与人员陈述及所附材料，不预设任何一方对争议结论的认可。"
    if mode == "policy":
        return f"{employer}为明确适用范围、管理标准和执行程序，依据已经完成的内部治理程序制定本文件。"
    return "提交方根据已经核验的事实、证据和程序材料，围绕争议焦点提出如下意见。"


def _display_title(document_id: str, default_title: str, request: GenericReconstructionRequest) -> str:
    context = f"{request.objective}{request.user_query}"
    if document_id == "R8" and "试用期" in context:
        prefix = "销售岗位" if "销售" in context else ""
        return f"{prefix}劳动合同（含试用期及录用条件）"
    return default_title


def _post_document_notes(request: GenericReconstructionRequest) -> list[str]:
    context = f"{request.objective}{request.user_query}"
    notes: list[str] = []
    if "R8" in request.selected_document_ids and "试用期" in context and "合同" in context:
        notes.extend([
            "适配说明：你要求的是“试用期合同”。本次没有忽略或改写你的需求，而是将文书处理为“劳动合同（含试用期及录用条件）”。法律上试用期必须包含在劳动合同期限内；如果合同只约定试用期，该试用期不成立，该期限直接视为劳动合同期限。",
            "三个月试用期条件：劳动合同应选择三年以上固定期限或者无固定期限；若选择一年以上不满三年的固定期限，试用期最长为二个月。签署前请使合同期限与三个月试用期保持一致。",
            "销售目标提示：月销售额30万元可以写入录用条件和考核标准，但应同时明确签约额／开票额／回款额口径、统计周期、退单处理、数据来源和企业提供的客户资源；未达目标不当然等于可以解除劳动合同。",
        ])
    if "X001" in request.selected_document_ids and any(word in context for word in ("员工手机号", "个人手机号", "不能换手机")):
        notes.extend([
            "适配说明：如果使用员工个人手机号注册企业账号，不宜把“员工永远不能换手机”写成无限制义务。文书将其转换为：未经公司书面同意不得擅自更换账号绑定方式；确需换机、换号时应提前通知并完成验证方式迁移。",
            "更稳妥方案：优先使用公司实名、公司付费并由公司控制的专用手机号、邮箱和设备注册企业账号，同时保留后台管理员和双重验证恢复方式，减少员工离职时无法交接的风险。",
        ])
    return notes


def _render_document(brief: Any, facts: dict[str, Any], review_required: bool, title: str | None = None) -> FullDocument:
    title = title or brief.title
    source_fact_fields = {key for key, value in facts.items() if value not in (None, "", [], {})}
    facts = {**brief.applicable_facts, **{key: value for key, value in facts.items() if value not in (None, "", [], {})}}
    sections = SPECIALIZED_SECTIONS.get(brief.document_id, MODE_SECTIONS[brief.generation_mode])
    profile_level = "representative_specialized_v1" if brief.document_id in SPECIALIZED_SECTIONS else "generic_mode_v1"
    consumed: set[str] = set()
    body = [title, "", _opening(brief.generation_mode, title, facts)]
    section_no = 1
    core_lines = [_value_line(field, facts[field]) for field in CORE_FIELDS if field in facts]
    if core_lines:
        body += ["", f"{section_no}、案件基础信息", *core_lines]
        consumed.update(field for field in CORE_FIELDS if field in facts)
        section_no += 1
    for heading, fields in sections:
        lines = []
        for field in fields:
            if field in facts and facts[field] not in (None, "", [], {}):
                lines.append(_value_line(field, facts[field]))
                consumed.add(field)
        if lines:
            body += ["", f"{section_no}、{heading}", *lines]
            section_no += 1

    supplemental = []
    if profile_level == "generic_mode_v1":
        supplemental = [field for field in brief.applicable_facts if field not in consumed and field not in CORE_FIELDS]
    if supplemental:
        body += ["", f"{section_no}、其他已确认事项"]
        body += [_value_line(field, facts[field]) for field in supplemental if field in facts]
        consumed.update(supplemental)
        section_no += 1

    body += ["", f"{section_no}、支持材料及核验"]
    body += [f"- {item}" for item in brief.evidence_requirements]
    body += [
        "",
        "上述事实仅以已经提供、能够核验且形成时间真实的材料为依据；未核实事项不得写成既成事实，历史缺口不得通过倒签或补造材料填补。",
        "",
        _signature_block(brief.generation_mode, facts),
        "",
        "使用提示：本方案用于完善事实、证据和程序记录，可降低争议风险，但不能替代对个案事实、当地规则和裁判尺度的核验。",
        "",
        f"免责声明：{DISCLAIMER}",
    ]
    if brief.document_id in STATIC_CLAUSES:
        insert_at = body.index(f"{section_no}、支持材料及核验")
        body[insert_at:insert_at] = [
            f"{section_no}、履行、争议与文本规则",
            *STATIC_CLAUSES[brief.document_id],
            "",
        ]
        body[insert_at + len(STATIC_CLAUSES[brief.document_id]) + 2] = f"{section_no + 1}、支持材料及核验"
    return FullDocument(
        document_id=brief.document_id,
        title=title,
        generation_mode=brief.generation_mode,
        profile_level=profile_level,
        content="\n".join(body).strip() + "\n",
        source_fact_fields=[field for field in brief.applicable_facts if field in consumed and field in source_fact_fields],
        evidence_requirements=brief.evidence_requirements,
        review_required=review_required,
    )


def generate_full_draft(
    request: GenericReconstructionRequest,
    capability_by_id: dict[str, dict],
) -> FullDraftResult:
    composed: GenericReconstructionResult = reconstruct_generic(request, capability_by_id)
    review_required = composed.status == "draft_ready_with_review"
    documents = []
    if composed.drafting_allowed:
        for brief in composed.drafting_briefs:
            documents.append(_render_document(
                brief,
                request.facts,
                review_required,
                _display_title(brief.document_id, brief.title, request),
            ))
    return FullDraftResult(
        case_id=request.case_id,
        status=composed.status,
        drafting_allowed=composed.drafting_allowed,
        questions=composed.questions,
        stop_reasons=composed.stop_reasons,
        legal_guard_findings=composed.legal_guard_findings,
        extracted_guard_facts=composed.extracted_guard_facts,
        fact_extraction_records=composed.fact_extraction_records,
        documents=documents,
        candidate_related_documents=composed.candidate_related_documents,
        review_notice=composed.final_notice,
        post_document_notes=_post_document_notes(request),
    )
DISCLAIMER = "法律文书和风险提示不代表法律意见，内容仅供参考，使用应自行承担风险和责任"
