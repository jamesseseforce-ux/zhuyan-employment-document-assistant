from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class FactRecord:
    field: str
    value: Any
    source_text: str
    rule_id: str
    document_ids: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["document_ids"] = list(self.document_ids)
        return data


def _compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def _uncertain(text: str, start: int) -> bool:
    prefix = text[max(0, start - 8):start]
    return any(word in prefix for word in ("是否", "是不是", "不确定", "不清楚", "尚不清楚", "不知道"))


def _add(records: list[FactRecord], field: str, value: Any, source: str, rule_id: str, documents: tuple[str, ...]) -> None:
    if any(item.field == field for item in records):
        return
    records.append(FactRecord(field, value, source, rule_id, documents))


def _first_match(text: str, patterns: tuple[str, ...]) -> re.Match[str] | None:
    for pattern in patterns:
        match = re.search(pattern, text)
        if match and not _uncertain(text, match.start()):
            return match
    return None


def extract_guard_facts(query: str) -> dict[str, Any]:
    text = _compact(query)
    records: list[FactRecord] = []

    accepted = _first_match(text, (r"(?:录用通知|offer)(?:已经|已)?(?:接受|确认|签收)", r"候选人(?:已经|已)?接受录用"))
    withdrawal = _first_match(text, (r"公司(?:想|拟|准备|打算|要)(?:撤回|撤销)录用", r"(?:想|拟|准备|打算)(?:撤回|撤销)(?:录用通知|offer)"))
    if accepted:
        _add(records, "offer_accepted", True, accepted.group(0), "E-R3-01", ("R3",))
    if withdrawal:
        _add(records, "employer_withdrawal_planned", True, withdrawal.group(0), "E-R3-02", ("R3",))

    probation = _first_match(text, (r"试用期?(?:约定|定|是|为)?(\d+(?:\.\d+)?)(个月|月|年)",))
    if probation:
        value = float(probation.group(1)) * (12 if probation.group(2) == "年" else 1)
        _add(records, "probation_months", value, probation.group(0), "E-R8-01", ("R8",))
    contract = _first_match(text, (
        r"(?:劳动合同|合同)(?:期限)?(?:签|约定|定|是|为)?(\d+(?:\.\d+)?)(个月|月|年)",
        r"签(\d+(?:\.\d+)?)(个月|月|年)(?:的)?(?:劳动合同|合同)",
    ))
    if contract:
        value = float(contract.group(1)) * (12 if contract.group(2) == "年" else 1)
        _add(records, "contract_term_months", value, contract.group(0), "E-R8-02", ("R8",))
        _add(records, "contract_term_type", "fixed", contract.group(0), "E-R8-03", ("R8",))
    open_ended = _first_match(text, (r"无固定期限(?:劳动合同)?",))
    if open_ended:
        _add(records, "contract_term_type", "open_ended", open_ended.group(0), "E-R8-04", ("R8",))
    task_term = _first_match(text, (r"以完成(?:一定)?工作任务为期限",))
    if task_term:
        _add(records, "contract_term_type", "task", task_term.group(0), "E-R8-05", ("R8",))
    sales_role = _first_match(text, (r"(?:销售岗|销售岗位|销售人员|销售专员|销售经理)",))
    if sales_role:
        _add(records, "work_content", "销售岗位，具体职责以岗位说明书及书面工作安排为准", sales_role.group(0), "E-R8-06", ("R8",))
    sales_target = _first_match(text, (
        r"(?:每月|月度)(?:销售额|回款额|业绩|销售业绩)(?:达到|完成|不低于|为)?(\d+(?:\.\d+)?)(万|元)",
        r"(?:试用期)?(?:业绩|销售额|回款额)(?:要求|目标|标准)(?:达到|完成|不低于|为)?(\d+(?:\.\d+)?)(万|元)",
    ))
    if sales_target:
        amount = float(sales_target.group(1)) * (10000 if sales_target.group(2) == "万" else 1)
        rendered = int(amount) if amount.is_integer() else amount
        _add(records, "performance_metrics", f"月度销售额目标为人民币{rendered}元；最终以双方确认的统计口径、数据来源及考核周期为准", sales_target.group(0), "E-R8-07", ("R8", "R71"))

    no_secret = _first_match(text, (
        r"(?:员工|他|她)?(?:从未|没有|没)(?:实际)?(?:知悉|接触)(?:过)?(?:公司)?(?:商业秘密|技术秘密|保密事项)",
        r"(?:普通员工|一般员工)(?:从未|没有|没)接触(?:商业秘密|保密事项)",
    ))
    if no_secret:
        _add(records, "actual_secret_access", False, no_secret.group(0), "E-R42-01", ("R42",))
    has_secret = _first_match(text, (
        r"(?:员工|他|她)?(?:实际|确实|已经|已)?(?:知悉|接触)(?:过|了)?(?:公司)?(?:商业秘密|技术秘密|保密事项)",
    ))
    if has_secret and not no_secret:
        _add(records, "actual_secret_access", True, has_secret.group(0), "E-R42-03", ("R42",))
    disproportionate = _first_match(text, (r"竞业(?:限制)?(?:范围|地域|期限)(?:明显)?(?:超过|超出|大于)(?:实际)?(?:秘密|接触|职责)(?:范围)?",))
    if disproportionate:
        _add(records, "restriction_proportionate", False, disproportionate.group(0), "E-R42-02", ("R42",))

    workday_comp = _first_match(text, (r"工作日(?:延时)?加班.{0,10}(?:只|仅)(?:给|安排)?调休",))
    holiday_comp = _first_match(text, (r"法定(?:节假日|休假日)加班.{0,10}(?:只|仅)(?:给|安排)?调休",))
    if workday_comp:
        _add(records, "overtime_date_type", "工作日", workday_comp.group(0), "E-R60-01", ("R60",))
        _add(records, "comp_time_only", True, workday_comp.group(0), "E-R60-02", ("R60",))
    if holiday_comp:
        _add(records, "overtime_date_type", "法定休假日", holiday_comp.group(0), "E-R60-03", ("R60",))
        _add(records, "comp_time_only", True, holiday_comp.group(0), "E-R60-04", ("R60",))

    waiver = _first_match(text, (r"(?:员工)?(?:签|出具|提交)(?:了|一份)?(?:自愿)?放弃社保(?:声明|承诺|协议)?", r"员工(?:自愿)?(?:不交|不缴|不要)社保"))
    cash_substitute = _first_match(text, (r"(?:发|给)(?:员工)?社保补贴.{0,8}(?:不交|不缴|替代)社保", r"用社保补贴(?:代替|替代)(?:缴纳)?社保"))
    if waiver:
        _add(records, "social_insurance_waiver", True, waiver.group(0), "E-R68-01", ("R68",))
    if cash_substitute:
        _add(records, "social_insurance_cash_substitute", True, cash_substitute.group(0), "E-R68-02", ("R68",))

    retro_metrics = _first_match(text, (
        r"(?:考核|结果)(?:结束|出来|完成|不合格)(?:以后|后).{0,8}(?:补签|补做|补定|倒签)(?:绩效)?(?:指标|目标|责任书|考核标准)",
        r"事后(?:补签|补做|补定|倒签)(?:绩效)?(?:指标|目标|责任书|考核标准)",
    ))
    if retro_metrics:
        _add(records, "metrics_set_before_cycle", False, retro_metrics.group(0), "E-R71-01", ("R71",))

    induced_injury_resignation = _first_match(text, (
        r"(?:让|要求|诱导|逼)(?:这个|该)?工伤员工(?:自己)?(?:写|签|提交)(?:个人)?辞职",
        r"工伤员工.{0,6}(?:诱导|逼迫|威胁)(?:个人)?辞职",
    ))
    if induced_injury_resignation:
        _add(records, "employer_induced_resignation", True, induced_injury_resignation.group(0), "E-R92-01", ("R92",))
        _add(records, "employee_voluntary_termination", False, induced_injury_resignation.group(0), "E-R92-02", ("R92",))

    salary_cut = _first_match(text, (r"调岗(?:同时|并|后)?(?:直接|单方)?降薪", r"调岗降薪"))
    no_salary_basis = _first_match(text, (
        r"(?:合同|制度)(?:里|中)?(?:没有|没)(?:约定|规定)(?:调岗|降薪|随岗定薪)",
        r"(?:没有|未)(?:和员工)?协商(?:降薪|工资调整)",
        r"降薪(?:没有|没)(?:合同|制度|协商)(?:依据)?",
    ))
    if salary_cut:
        _add(records, "salary_reduction_planned", True, salary_cut.group(0), "E-F22-01", ("F22",))
    if no_salary_basis:
        _add(records, "salary_change_basis_confirmed", False, no_salary_basis.group(0), "E-F22-02", ("F22",))

    invalid_rule = _first_match(text, (r"(?:规章制度|员工手册|制度)(?:没有|没|未)(?:经过)?(?:民主程序|公示|告知|签收)",))
    weak_evidence = _first_match(text, (r"(?:严重违纪|飞单|泄密|挖角).{0,8}(?:没有证据|无证据|证据不足|证据不充分)", r"(?:没有证据|无证据|证据不足|证据不充分).{0,8}(?:严重违纪|飞单|泄密|挖角)"))
    late_union = _first_match(text, (r"(?:已经|已)(?:解除|辞退|开除).{0,10}(?:再|才|事后)(?:通知|补通知)工会", r"解除后(?:再|才|补)(?:通知)?工会"))
    if invalid_rule:
        _add(records, "rule_validity_confirmed", False, invalid_rule.group(0), "E-F57-01", ("F57",))
    if weak_evidence:
        _add(records, "misconduct_evidence_sufficient", False, weak_evidence.group(0), "E-F57-02", ("F57",))
    if late_union:
        _add(records, "termination_already_issued", True, late_union.group(0), "E-F57-03", ("F57",))
        _add(records, "union_notice_timing", "解除后", late_union.group(0), "E-F57-04", ("F57",))

    no_training_transfer = _first_match(text, (
        r"(?:既|不但)?(?:没有|没)(?:实际)?培训(?:也|又|且|或者)(?:没有|没)(?:实际)?调岗",
        r"培训和调岗(?:都)?(?:没有|没)(?:做|实施|进行)",
    ))
    short_observation = _first_match(text, (r"观察期(?:明显)?(?:太短|不足)",))
    changed_second_standard = _first_match(text, (r"(?:第二次|再次)考核(?:后|时)?(?:临时|事后)?(?:改变|更改|提高)(?:了)?(?:标准|合格线|指标)",))
    if no_training_transfer:
        _add(records, "actual_training_or_transfer_completed", False, no_training_transfer.group(0), "E-F58-01", ("F58",))
    if short_observation:
        _add(records, "observation_period_reasonable", False, short_observation.group(0), "E-F58-02", ("F58",))
    if changed_second_standard:
        _add(records, "second_assessment_standard_changed", True, changed_second_standard.group(0), "E-F58-03", ("F58",))

    revenue_only = _first_match(text, (r"(?:只是|仅仅|只有|单纯)(?:经营|营收|业绩)(?:下降|下滑|不好|困难)",))
    still_perform = _first_match(text, (r"(?:原)?劳动合同(?:仍然|仍|还)(?:能|可以)(?:继续)?履行", r"岗位(?:仍然|仍|还)(?:存在|保留)"))
    if revenue_only:
        _add(records, "business_change_only_revenue_decline", True, revenue_only.group(0), "E-F60-01", ("F60",))
    if still_perform:
        _add(records, "contract_performance_impossible", False, still_perform.group(0), "E-F60-02", ("F60",))
    affected = _first_match(text, (r"(?:裁员|裁减|减员|辞退|解除|优化)(\d+)个?人",))
    workforce = _first_match(text, (r"(?:公司|企业|全公司|职工总数|员工总数|现有|一共|总共)(?:有|共|是|约)?(\d+)个?人",))
    if affected:
        _add(records, "affected_headcount", int(affected.group(1)), affected.group(0), "E-F60-03", ("F60",))
    if workforce:
        _add(records, "workforce_total", int(workforce.group(1)), workforce.group(0), "E-F60-04", ("F60",))

    facts = {item.field: item.value for item in records}
    document_ids = list(dict.fromkeys(document_id for item in records for document_id in item.document_ids))
    return {
        "facts": facts,
        "records": [item.to_dict() for item in records],
        "relevant_document_ids": document_ids,
    }
