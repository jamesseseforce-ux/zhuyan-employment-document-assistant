from __future__ import annotations

import base64
import hashlib
import io
import json
import re
from typing import Any, Literal

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from pydantic import BaseModel, ConfigDict, Field

try:
    from tools.conversation_case_state_v1 import DialogueState
    from tools.evaluate_full_drafts_v1 import evaluate_full_draft
    from tools.full_document_generator_v1 import FullDocument, generate_full_draft
    from tools.generic_reconstruction_orchestrator import GenericReconstructionRequest
except ModuleNotFoundError:
    from conversation_case_state_v1 import DialogueState
    from evaluate_full_drafts_v1 import evaluate_full_draft
    from full_document_generator_v1 import FullDocument, generate_full_draft
    from generic_reconstruction_orchestrator import GenericReconstructionRequest


NOTICE = "本方案用于完善事实、证据和程序记录，可降低争议风险，但不能替代对个案事实、当地规则和裁判尺度的核验。"
DISCLAIMER = "法律文书和风险提示不代表法律意见，内容仅供参考，使用应自行承担风险和责任"


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DeliveryRequest(StrictModel):
    state: DialogueState
    formats: list[Literal["docx", "markdown", "json"]] = Field(
        default_factory=lambda: ["docx", "markdown", "json"], min_length=1, max_length=3
    )


class DeliveryArtifact(StrictModel):
    document_id: str | None
    filename: str
    mime_type: str
    encoding: Literal["base64", "utf-8"]
    size_bytes: int
    sha256: str
    content: str


class DeliveryResult(StrictModel):
    case_id: str
    status: Literal["blocked", "needs_information", "delivery_ready"]
    drafting_allowed: bool
    questions: list[str]
    stop_reasons: list[str]
    evaluation: dict[str, Any] | None
    artifacts: list[DeliveryArtifact]
    review_notice: str
    post_document_notes: list[str] = Field(default_factory=list)


def _set_font(run: Any, western: str, east_asia: str, size: float, bold: bool | None = None, color: str | None = None) -> None:
    run.font.name = western
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), western)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), western)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east_asia)
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _set_style_font(style: Any, western: str, east_asia: str, size: float, color: str | None = None, bold: bool | None = None) -> None:
    style.font.name = western
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), western)
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), western)
    style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east_asia)
    style.font.size = Pt(size)
    if color:
        style.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        style.font.bold = bold


def _add_numbering(document: Document) -> int:
    numbering = document.part.numbering_part.element
    abstract_ids = [int(item.get(qn("w:abstractNumId"))) for item in numbering.findall(qn("w:abstractNum"))]
    num_ids = [int(item.get(qn("w:numId"))) for item in numbering.findall(qn("w:num"))]
    next_abstract = max(abstract_ids, default=0) + 1
    next_num = max(num_ids, default=0) + 1

    def create(fmt: str, text: str, left: int, hanging: int, font: str = "Calibri") -> int:
        nonlocal next_abstract, next_num
        abstract = OxmlElement("w:abstractNum")
        abstract.set(qn("w:abstractNumId"), str(next_abstract))
        multi = OxmlElement("w:multiLevelType")
        multi.set(qn("w:val"), "singleLevel")
        abstract.append(multi)
        level = OxmlElement("w:lvl")
        level.set(qn("w:ilvl"), "0")
        start = OxmlElement("w:start")
        start.set(qn("w:val"), "1")
        level.append(start)
        num_fmt = OxmlElement("w:numFmt")
        num_fmt.set(qn("w:val"), fmt)
        level.append(num_fmt)
        lvl_text = OxmlElement("w:lvlText")
        lvl_text.set(qn("w:val"), text)
        level.append(lvl_text)
        suff = OxmlElement("w:suff")
        suff.set(qn("w:val"), "tab")
        level.append(suff)
        ppr = OxmlElement("w:pPr")
        tabs = OxmlElement("w:tabs")
        tab = OxmlElement("w:tab")
        tab.set(qn("w:val"), "num")
        tab.set(qn("w:pos"), str(left))
        tabs.append(tab)
        ppr.append(tabs)
        ind = OxmlElement("w:ind")
        ind.set(qn("w:left"), str(left))
        ind.set(qn("w:hanging"), str(hanging))
        ppr.append(ind)
        level.append(ppr)
        rpr = OxmlElement("w:rPr")
        fonts = OxmlElement("w:rFonts")
        fonts.set(qn("w:ascii"), font)
        fonts.set(qn("w:hAnsi"), font)
        fonts.set(qn("w:eastAsia"), "宋体")
        rpr.append(fonts)
        level.append(rpr)
        abstract.append(level)
        numbering.append(abstract)
        num = OxmlElement("w:num")
        num.set(qn("w:numId"), str(next_num))
        abstract_ref = OxmlElement("w:abstractNumId")
        abstract_ref.set(qn("w:val"), str(next_abstract))
        num.append(abstract_ref)
        numbering.append(num)
        created_num = next_num
        next_abstract += 1
        next_num += 1
        return created_num

    return create("bullet", "•", 540, 270, "Calibri")


def _apply_num(paragraph: Any, num_id: int) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num = OxmlElement("w:numId")
    num.set(qn("w:val"), str(num_id))
    num_pr.extend([ilvl, num])
    ppr.append(num_pr)


def _add_page_number(paragraph: Any) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instruction = OxmlElement("w:instrText")
    instruction.set(qn("xml:space"), "preserve")
    instruction.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instruction, separate, text, end])
    _set_font(run, "Calibri", "宋体", 9, color="777777")


def _configure_document(document: Document) -> int:
    settings = document.settings.element
    even_odd = settings.find(qn("w:evenAndOddHeaders"))
    if even_odd is not None:
        settings.remove(even_odd)
    section = document.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = document.styles["Normal"]
    _set_style_font(normal, "Calibri", "宋体", 11)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for name, size, color, before, after in (
        ("Heading 1", 16, "2E74B5", 18, 10),
        ("Heading 2", 13, "2E74B5", 14, 7),
        ("Heading 3", 12, "1F4D78", 10, 5),
    ):
        style = document.styles[name]
        _set_style_font(style, "Calibri", "黑体", size, color=color, bold=True)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    header = section.header.paragraphs[0]
    header.text = ""
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_font(header.add_run("铸言 企业用工文书"), "Calibri", "宋体", 9, color="555555")
    _add_page_number(section.footer.paragraphs[0])
    return _add_numbering(document)


def build_docx_bytes(item: FullDocument, notice: str, post_document_notes: list[str] | None = None) -> bytes:
    document = Document()
    document.core_properties.title = item.title
    document.core_properties.subject = "企业用工定制法律文书草稿"
    document.core_properties.author = ""
    bullet_num = _configure_document(document)
    lines = [
        line for line in item.content.strip().splitlines()
        if DISCLAIMER not in line
    ]
    title = lines[0] if lines else item.title
    title_p = document.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(0)
    title_p.paragraph_format.space_after = Pt(6)
    title_p.paragraph_format.keep_with_next = True
    _set_font(title_p.add_run(title), "Calibri", "黑体", 20, bold=True, color="000000")
    tag = document.add_paragraph()
    tag.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tag.paragraph_format.space_after = Pt(14)
    _set_font(tag.add_run("定制草稿 · 签署前完成个案及当地规则核验"), "Calibri", "宋体", 9.5, color="777777")

    section_pattern = re.compile(r"^\d+、(.+)$")
    for line in lines[1:]:
        text = line.strip()
        if not text:
            continue
        section_match = section_pattern.match(text)
        if section_match:
            paragraph = document.add_paragraph(style="Heading 1")
            paragraph.add_run(text)
        elif text.startswith("- "):
            paragraph = document.add_paragraph()
            paragraph.paragraph_format.left_indent = Inches(0.375)
            paragraph.paragraph_format.first_line_indent = Inches(-0.188)
            paragraph.paragraph_format.space_after = Pt(4)
            paragraph.paragraph_format.line_spacing = 1.25
            paragraph.add_run(text[2:])
            _apply_num(paragraph, bullet_num)
        else:
            paragraph = document.add_paragraph(text)
            paragraph.paragraph_format.widow_control = True

    note = document.add_paragraph()
    note.paragraph_format.space_before = Pt(12)
    note.paragraph_format.space_after = Pt(0)
    note.paragraph_format.keep_together = True
    note_pr = note._p.get_or_add_pPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), "F4F6F9")
    note_pr.append(shading)
    run = note.add_run("审校提示：" + notice)
    _set_font(run, "Calibri", "宋体", 9.5, color="555555")
    if post_document_notes:
        heading = document.add_paragraph(style="Heading 1")
        heading.add_run("文书适配与风险说明")
        for item_note in post_document_notes:
            paragraph = document.add_paragraph(item_note)
            paragraph.paragraph_format.widow_control = True

    disclaimer = document.add_paragraph()
    disclaimer.paragraph_format.space_before = Pt(12)
    disclaimer.paragraph_format.space_after = Pt(0)
    disclaimer.paragraph_format.keep_together = True
    _set_font(disclaimer.add_run("免责声明：" + DISCLAIMER), "Calibri", "宋体", 9, color="666666")

    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def _artifact(document_id: str | None, filename: str, mime: str, data: bytes, encoding: Literal["base64", "utf-8"]) -> DeliveryArtifact:
    content = base64.b64encode(data).decode("ascii") if encoding == "base64" else data.decode("utf-8")
    return DeliveryArtifact(
        document_id=document_id,
        filename=filename,
        mime_type=mime,
        encoding=encoding,
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        content=content,
    )


def _safe_name(value: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return cleaned[:80] or "document"


def build_delivery_package(request: DeliveryRequest, capability_by_id: dict[str, dict]) -> DeliveryResult:
    state = request.state
    if not state.selected_document_ids:
        return DeliveryResult(
            case_id=state.case_id, status="needs_information", drafting_allowed=False,
            questions=["尚未确认需要生成的主文书，请先通过dialogue操作确定selected_document_ids。"],
            stop_reasons=[], evaluation=None, artifacts=[], review_notice=NOTICE,
        )
    delivery_facts = dict(state.facts)
    for conflict in state.conflicts:
        delivery_facts.pop(conflict["field"], None)
    case = GenericReconstructionRequest(
        case_id=state.case_id,
        objective=state.objective,
        user_query=state.objective,
        selected_document_ids=state.selected_document_ids,
        facts=delivery_facts,
        not_applicable_fields=state.not_applicable_fields,
        confirmed_preconditions=state.confirmed_preconditions,
        confirmed_evidence_requirements=state.confirmed_evidence_requirements,
        stop_node_hits=state.stop_node_hits,
        local_rules_checked=state.local_rules_checked,
    )
    draft = generate_full_draft(case, capability_by_id)
    evaluation = evaluate_full_draft(case.model_dump(mode="json"), draft)

    artifacts: list[DeliveryArtifact] = []
    formats = list(dict.fromkeys(request.formats))
    if "docx" in formats:
        for item in draft.documents:
            filename = f"{item.document_id}-{_safe_name(item.title)}.docx"
            artifacts.append(_artifact(item.document_id, filename, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", build_docx_bytes(item, draft.review_notice, draft.post_document_notes), "base64"))
    if "markdown" in formats:
        parts = [f"# 案件 {state.case_id} 定制文书包"]
        for item in draft.documents:
            clean_content = "\n".join(
                line for line in item.content.strip().splitlines() if DISCLAIMER not in line
            )
            parts += ["", f"## {item.document_id} {item.title}", "", clean_content]
        if draft.post_document_notes:
            parts += ["", "## 文书适配与风险说明", ""]
            parts += [f"- {item}" for item in draft.post_document_notes]
        parts += ["", "## 审校提示", "", draft.review_notice]
        parts += ["", "免责声明：" + DISCLAIMER]
        payload = ("\n".join(parts).strip() + "\n").encode("utf-8")
        artifacts.append(_artifact(None, f"{_safe_name(state.case_id)}-定制文书包.md", "text/markdown", payload, "utf-8"))
    if "json" in formats:
        payload = json.dumps({
            "case_id": state.case_id,
            "status": draft.status,
            "documents": [item.model_dump(mode="json") for item in draft.documents],
            "evaluation": evaluation.model_dump(mode="json"),
            "review_notice": draft.review_notice,
            "post_document_notes": draft.post_document_notes,
        }, ensure_ascii=False, indent=2).encode("utf-8")
        artifacts.append(_artifact(None, f"{_safe_name(state.case_id)}-定制文书包.json", "application/json", payload, "utf-8"))
    return DeliveryResult(
        case_id=state.case_id, status="delivery_ready", drafting_allowed=True,
        questions=draft.questions, stop_reasons=draft.stop_reasons + evaluation.failures, evaluation=evaluation.model_dump(mode="json"),
        artifacts=artifacts, review_notice=draft.review_notice,
        post_document_notes=draft.post_document_notes,
    )


def save_artifacts(result: DeliveryResult, output_dir: Any) -> list[Any]:
    from pathlib import Path

    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    paths = []
    for artifact in result.artifacts:
        data = base64.b64decode(artifact.content) if artifact.encoding == "base64" else artifact.content.encode("utf-8")
        path = target / artifact.filename
        path.write_bytes(data)
        paths.append(path)
    return paths
