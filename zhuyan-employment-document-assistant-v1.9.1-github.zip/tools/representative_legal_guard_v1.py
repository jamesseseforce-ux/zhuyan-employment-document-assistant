from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal


GuardOutcome = Literal["needs_information", "blocked", "reroute"]


@dataclass(frozen=True)
class GuardFinding:
    document_id: str
    rule_id: str
    outcome: GuardOutcome
    reason: str
    legal_basis: str
    action: str
    questions: tuple[str, ...] = ()
    suggested_document_ids: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["questions"] = list(self.questions)
        data["suggested_document_ids"] = list(self.suggested_document_ids)
        return data


def _true(facts: dict[str, Any], field: str) -> bool:
    return facts.get(field) is True


def _false(facts: dict[str, Any], field: str) -> bool:
    return facts.get(field) is False


def _text(facts: dict[str, Any], field: str) -> str:
    return str(facts.get(field, "")).strip().lower()


def _number(facts: dict[str, Any], field: str) -> float | None:
    value = facts.get(field)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _probation_limit_months(contract_months: float | None, term_type: str) -> float | None:
    if term_type in {"task", "以完成一定工作任务为期限", "less_than_three_months", "不满三个月"}:
        return 0
    if term_type in {"open_ended", "无固定期限"}:
        return 6
    if contract_months is None:
        return None
    if contract_months < 3:
        return 0
    if contract_months < 12:
        return 1
    if contract_months < 36:
        return 2
    return 6


def evaluate_representative_legal_guard(
    selected_document_ids: list[str], facts: dict[str, Any]
) -> list[GuardFinding]:
    selected = set(selected_document_ids)
    findings: list[GuardFinding] = []

    if "R3" in selected and _true(facts, "offer_accepted") and _true(facts, "employer_withdrawal_planned"):
        findings.append(GuardFinding(
            "R3", "R3-G01", "blocked",
            "录用通知已被接受后，企业拟直接撤回；继续生成普通录用通知或无责任撤回文本会掩盖已经形成的信赖风险。",
            "《民法典》第五百条及劳动关系自实际用工之日起建立的规则。",
            "先分析通知内容、接受方式和候选人是否已辞职、搬迁或支出费用，再决定继续履行、协商补偿或承担缔约过失责任。",
            ("候选人何时、以何种方式接受录用，是否已据此辞职或发生可证明的损失？",),
        ))

    if "R8" in selected:
        probation = _number(facts, "probation_months")
        contract_months = _number(facts, "contract_term_months")
        limit = _probation_limit_months(contract_months, _text(facts, "contract_term_type"))
        if probation is not None and limit is None:
            findings.append(GuardFinding(
                "R8", "R8-G01", "needs_information",
                "已填写试用期月数，但缺少可判断法定上限的合同期限类型或期限月数。",
                "《劳动合同法》第十九条。",
                "补齐合同期限后再生成含试用期的劳动合同。",
                ("劳动合同是固定期限、无固定期限还是以完成一定工作任务为期限；固定期限共多少个月？",),
            ))
        elif probation is not None and limit is not None and probation > limit:
            findings.append(GuardFinding(
                "R8", "R8-G02", "blocked",
                f"拟约定试用期{probation:g}个月，超过该合同期限对应的法定上限{limit:g}个月。",
                "《劳动合同法》第十九条、第八十三条。",
                "将试用期缩短至法定上限以内，并核对是否已经实际履行违法试用期及相应赔偿风险。",
            ))

    if "R42" in selected:
        if _false(facts, "actual_secret_access"):
            findings.append(GuardFinding(
                "R42", "R42-G01", "blocked",
                "已确认员工未知悉、未接触商业秘密或与知识产权相关的保密事项，离职竞业限制缺少生效基础。",
                "《劳动争议司法解释（二）》第十三条。",
                "改用与实际信息接触范围相匹配的保密、资料返还和在职忠实义务安排，不生成离职竞业限制。",
            ))
        if _false(facts, "restriction_proportionate"):
            findings.append(GuardFinding(
                "R42", "R42-G02", "blocked",
                "竞业业务、地域或期限与员工实际接触的秘密范围不相适应。",
                "《劳动合同法》第二十三条、第二十四条及《劳动争议司法解释（二）》第十三条。",
                "按秘密点、竞争业务和员工实际职责缩窄范围，再确定是否启动竞业限制。",
            ))

    if "R60" in selected:
        date_type = _text(facts, "overtime_date_type")
        compensation = _text(facts, "statutory_compensation")
        comp_time_only = _true(facts, "comp_time_only") or compensation in {"调休", "仅调休", "comp_time_only"}
        if date_type in {"工作日", "workday"} and comp_time_only:
            findings.append(GuardFinding(
                "R60", "R60-G01", "blocked",
                "标准工时制工作日延时仅安排调休，不能替代不低于150%的加班工资。",
                "《劳动法》第四十四条第一项。",
                "改为依法核算并支付工作日延时加班工资；调休只能作为额外安排。",
            ))
        if date_type in {"法定休假日", "法定节假日", "statutory_holiday"} and comp_time_only:
            findings.append(GuardFinding(
                "R60", "R60-G02", "blocked",
                "法定休假日加班仅安排调休，不能替代不低于300%的加班工资。",
                "《劳动法》第四十四条第三项。",
                "改为依法核算并支付法定休假日加班工资。",
            ))

    if "R68" in selected and (_true(facts, "social_insurance_waiver") or _true(facts, "social_insurance_cash_substitute")):
        findings.append(GuardFinding(
            "R68", "R68-G01", "blocked",
            "员工放弃声明或现金补贴不能替代法定参保缴费。",
            "《社会保险法》第五十八条、第六十条、第六十三条、第八十六条及《劳动争议司法解释（二）》第十九条。",
            "按真实劳动关系、期间和缴费基数核算补缴或更正方案，逐笔核对历史补贴，但不把补贴写成免除参保义务。",
        ))

    if "R71" in selected and _false(facts, "metrics_set_before_cycle"):
        findings.append(GuardFinding(
            "R71", "R71-G01", "blocked",
            "绩效指标、权重或合格线未在考核周期开始前确定，不能倒填成前置目标责任书。",
            "《劳动合同法》第四条、第三十五条、第四十条第二项。",
            "如实保留历史缺口；仅为下一考核周期制定前置指标，既往评价另按当时已经明确的标准和证据处理。",
        ))

    if "R92" in selected and _true(facts, "employer_induced_resignation") and not _true(facts, "employee_voluntary_termination"):
        findings.append(GuardFinding(
            "R92", "R92-G01", "blocked",
            "企业拟诱导工伤员工以个人辞职名义终止劳动关系，不能直接生成“员工自愿提出解除”的待遇结算协议。",
            "《工伤保险条例》第三十七条及《劳动合同法》第四十二条。",
            "先核验伤残等级、限制解除情形和真实终止路径；如需结束关系，改用符合法定触发条件的协商或终止方案并核算全部待遇。",
        ))

    if "F22" in selected and _true(facts, "salary_reduction_planned") and _false(facts, "salary_change_basis_confirmed"):
        findings.append(GuardFinding(
            "F22", "F22-G01", "reroute",
            "调岗同时拟降薪，但合同、有效制度、协商或合理性依据尚未确认；不能把调岗通知包装成当然单方降薪权。",
            "《劳动合同法》第三十五条、第四十条第二项。",
            "调岗与调薪分开处理：先生成不改变既有固定工资的合理调岗方案，薪酬变化另行协商或核验有效制度依据。",
            ("固定工资是否变化；劳动合同、薪酬制度或双方协商分别提供了什么具体依据？",),
        ))

    if "F57" in selected:
        if _false(facts, "rule_validity_confirmed") or _false(facts, "misconduct_evidence_sufficient"):
            findings.append(GuardFinding(
                "F57", "F57-G01", "blocked",
                "严重违纪解除所需的有效制度或事实证据已明确不足。",
                "《劳动合同法》第四条、第三十九条第二项。",
                "保存现有原始证据并完成合法调查；根据已经存在的事实选择较轻处分、继续履行或其他真实路径，不补造制度和证据。",
            ))
        if _true(facts, "termination_already_issued") and _text(facts, "union_notice_timing") in {"解除后", "after_termination"}:
            findings.append(GuardFinding(
                "F57", "F57-G02", "blocked",
                "解除决定已经作出后才拟通知工会，不能在新文书中写成解除前已完成程序。",
                "《劳动合同法》第四十三条。",
                "如实记录实际时间线并进行个案程序风险评估，不倒填或改写工会通知时间。",
            ))

    if "F58" in selected:
        reasons = []
        if _false(facts, "actual_training_or_transfer_completed"):
            reasons.append("培训或调岗未真实实施")
        if _false(facts, "observation_period_reasonable"):
            reasons.append("观察期明显不足")
        if _true(facts, "second_assessment_standard_changed"):
            reasons.append("再次考核标准事后改变")
        if reasons:
            findings.append(GuardFinding(
                "F58", "F58-G01", "blocked",
                "、".join(reasons) + "，尚不具备以再次不能胜任为由终局解除的事实链。",
                "《劳动合同法》第四十条第二项。",
                "补做真实管理措施只能面向未来，不得倒填；待真实培训或合理调岗、合理观察和同口径再次考核完成后重新判断。",
            ))

    if "F60" in selected:
        if _true(facts, "business_change_only_revenue_decline") or _false(facts, "contract_performance_impossible"):
            findings.append(GuardFinding(
                "F60", "F60-G01", "blocked",
                "仅有经营下降，或者现有事实尚未导致原劳动合同无法履行，不足以直接进入客观情况重大变化解除。",
                "《劳动合同法》第四十条第三项。",
                "先论证订约基础发生何种变化、为何无法继续履行，并提出真实可行的变更方案；不能证明时改走协商、正常履行或其他真实路径。",
            ))
        affected = _number(facts, "affected_headcount")
        workforce = _number(facts, "workforce_total")
        reaches_layoff = affected is not None and (affected >= 20 or (workforce and affected < 20 and affected / workforce >= 0.1))
        if reaches_layoff:
            findings.append(GuardFinding(
                "F60", "F60-G02", "reroute",
                "拟处理人数或比例达到经济性裁员分流条件，不能继续按单个客观情况变化解除批量处理。",
                "《劳动合同法》第四十一条。",
                "转入经济性裁员路径，核验法定事由、提前说明、听取意见、报告、人员保护和优先留用等程序。",
                ("本次裁减对应重整、严重经营困难、转产技术革新经营方式调整，还是其他客观经济变化中的哪一项？", "是否已筛查限制解除人员和优先留用人员，并拟定说明、听取意见及行政报告时间表？"),
                suggested_document_ids=("F61",),
            ))

    return findings
