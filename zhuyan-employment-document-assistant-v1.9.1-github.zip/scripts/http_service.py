#!/usr/bin/env python3
"""Authenticated HTTP wrapper around the single Skill runtime."""

from __future__ import annotations

import hmac
import json
import os
import sys
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

try:
    from .skill_runtime import execute, find_project_root
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from skill_runtime import execute, find_project_root


RUNTIME_VERSION = "1.9.1"
MAX_REQUEST_BYTES = 5 * 1024 * 1024
ROOT = find_project_root(Path(__file__).resolve())


def _api_key() -> str:
    return os.environ.get("EMPLOYMENT_SKILL_API_KEY", "").strip()


def _authorized(header: str | None) -> bool:
    expected = _api_key()
    if not expected or not header or not header.startswith("Bearer "):
        return False
    return hmac.compare_digest(header[7:].strip(), expected)


class RuntimeHandler(BaseHTTPRequestHandler):
    server_version = "EmploymentSkillCore/1.8"

    def log_message(self, format: str, *args: Any) -> None:
        return

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path != "/health":
            self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
            return
        self._json(HTTPStatus.OK, {"status": "ok", "runtime_version": RUNTIME_VERSION})

    def do_POST(self) -> None:
        if self.path != "/v1/execute":
            self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
            return
        if not _api_key():
            self._json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "api_key_not_configured"})
            return
        if not _authorized(self.headers.get("Authorization")):
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._json(HTTPStatus.BAD_REQUEST, {"error": "invalid_content_length"})
            return
        if length <= 0 or length > MAX_REQUEST_BYTES:
            self._json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": "request_size_invalid"})
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("请求体必须为JSON对象。")
            response = execute(payload, ROOT)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            self._json(HTTPStatus.UNPROCESSABLE_ENTITY, {"error": "invalid_request", "detail": str(exc)})
            return
        self._json(HTTPStatus.OK, response)


def main() -> int:
    if not _api_key():
        raise SystemExit("必须通过 EMPLOYMENT_SKILL_API_KEY 配置服务密钥。")
    host = os.environ.get("EMPLOYMENT_SKILL_HOST", "127.0.0.1")
    port = int(os.environ.get("EMPLOYMENT_SKILL_PORT", "8000"))
    server = ThreadingHTTPServer((host, port), RuntimeHandler)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
