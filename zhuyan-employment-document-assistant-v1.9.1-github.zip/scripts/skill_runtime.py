#!/usr/bin/env python3
"""Single local entrypoint for intake routing and document reconstruction."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def find_project_root(start: Path) -> Path:
    for candidate in (start, *start.parents):
        if (candidate / "core" / "v1" / "knowledge" / "documents.json").exists():
            return candidate
    raise SystemExit("未找到235份文书知识目录；请在用工文书智能体项目内运行。")


def execute(request: dict, root: Path) -> dict:
    sys.path.insert(0, str(root / "tools"))
    operation = request.get("operation")
    capabilities_path = root / "core" / "v1" / "capabilities" / "document-capabilities.json"
    capability_data = json.loads(capabilities_path.read_text(encoding="utf-8"))
    capability_rows = list(capability_data["documents"])
    extension_path = capabilities_path.with_name("extension-document-capabilities.json")
    if extension_path.exists():
        capability_rows.extend(json.loads(extension_path.read_text(encoding="utf-8"))["documents"])
    capability_by_id = {item["document_id"]: item for item in capability_rows}
    for document_id, title in {
        "R8": "劳动合同书（通用标准版）",
        "F66": "劳动合同补签及签署确认书",
    }.items():
        if document_id in capability_by_id:
            capability_by_id[document_id] = {**capability_by_id[document_id], "title": title}
    if operation == "intake":
        from intake_question_engine import intake, load_documents
        from legal_fact_extractor_v1 import extract_guard_facts
        from representative_legal_guard_v1 import evaluate_representative_legal_guard

        query = str(request.get("query", "")).strip()
        if not query:
            raise ValueError("intake 操作必须提供非空 query。")
        documents = load_documents(root / "core" / "v1" / "knowledge" / "documents.json")
        result = intake(query, documents).model_dump(mode="json")
        result["catalog_document_count"] = len(documents)
        result["base_document_count"] = len(capability_data["documents"])
        result["extension_document_count"] = len(capability_rows) - len(capability_data["documents"])
        result["candidate_capabilities"] = [
            {
                "document_id": candidate["document_id"],
                "risk_level": capability_by_id[candidate["document_id"]]["risk_level"],
                "calibration": capability_by_id[candidate["document_id"]]["calibration"],
                "required_fields": capability_by_id[candidate["document_id"]]["required_fields"],
                "preconditions": capability_by_id[candidate["document_id"]]["preconditions"],
                "stop_nodes": capability_by_id[candidate["document_id"]]["stop_nodes"],
            }
            for candidate in result["candidate_documents"]
        ]
        extraction = extract_guard_facts(query)
        result["extracted_guard_facts"] = extraction["facts"]
        result["fact_extraction_records"] = extraction["records"]
        guard_document_ids = list(dict.fromkeys(
            [item["document_id"] for item in result["candidate_documents"]]
            + extraction["relevant_document_ids"]
        ))
        result["preliminary_legal_guard_findings"] = [
            item.to_dict() for item in evaluate_representative_legal_guard(guard_document_ids, extraction["facts"])
        ]
        result["fast_path"] = {
            "single_pass": True,
            "external_search_required_before_first_response": False,
            "recommended_follow_up_operation": None,
        }
        if result["mode"] == "direct" and result["candidate_documents"]:
            from full_document_generator_v1 import generate_full_draft
            from generic_reconstruction_orchestrator import GenericReconstructionRequest

            selected_id = result["candidate_documents"][0]["document_id"]
            first_draft = generate_full_draft(
                GenericReconstructionRequest(
                    case_id="first-response",
                    objective=query,
                    user_query=query,
                    selected_document_ids=[selected_id],
                    facts=extraction["facts"],
                ),
                capability_by_id,
            )
            if first_draft.documents:
                result["first_response_document"] = first_draft.documents[0].model_dump(mode="json")
                result["post_document_notes"] = first_draft.post_document_notes
                result["fast_path"]["document_generated"] = True
            else:
                result["fast_path"]["document_generated"] = False
    elif operation == "reconstruct":
        from dynamic_reconstruction_engine import ReconstructionScenario, reconstruct

        scenario = request.get("scenario")
        if not isinstance(scenario, dict):
            raise ValueError("reconstruct 操作必须提供 scenario 对象。")
        result = reconstruct(ReconstructionScenario.model_validate(scenario)).model_dump(mode="json")
    elif operation == "compose":
        from generic_reconstruction_orchestrator import GenericReconstructionRequest, reconstruct_generic

        case = request.get("case")
        if not isinstance(case, dict):
            raise ValueError("compose 操作必须提供 case 对象。")
        result = reconstruct_generic(GenericReconstructionRequest.model_validate(case), capability_by_id).model_dump(mode="json")
    elif operation == "draft":
        from full_document_generator_v1 import generate_full_draft
        from generic_reconstruction_orchestrator import GenericReconstructionRequest

        case = request.get("case")
        if not isinstance(case, dict):
            raise ValueError("draft 操作必须提供 case 对象。")
        result = generate_full_draft(GenericReconstructionRequest.model_validate(case), capability_by_id).model_dump(mode="json")
    elif operation == "dialogue":
        from conversation_case_state_v1 import DialogueRequest, advance_dialogue
        from intake_question_engine import load_documents

        turn = request.get("turn")
        if not isinstance(turn, dict):
            raise ValueError("dialogue 操作必须提供 turn 对象。")
        documents = load_documents(root / "core" / "v1" / "knowledge" / "documents.json")
        result = advance_dialogue(
            DialogueRequest.model_validate(turn), documents, capability_by_id
        ).model_dump(mode="json")
    elif operation == "deliver":
        from delivery_pipeline_v1 import DeliveryRequest, build_delivery_package

        delivery = request.get("delivery")
        if not isinstance(delivery, dict):
            raise ValueError("deliver 操作必须提供 delivery 对象。")
        result = build_delivery_package(
            DeliveryRequest.model_validate(delivery), capability_by_id
        ).model_dump(mode="json")
    elif operation == "capability":
        document_ids = request.get("document_ids")
        if not isinstance(document_ids, list) or not 1 <= len(document_ids) <= 10:
            raise ValueError("capability 操作必须提供1至10个 document_ids。")
        unknown = [item for item in document_ids if item not in capability_by_id]
        if unknown:
            raise ValueError(f"未知文书编号：{','.join(unknown)}")
        result = {
            "capability_document_count": len(capability_by_id),
            "documents": [capability_by_id[item] for item in document_ids],
        }
    else:
        raise ValueError("operation 仅支持 intake、dialogue、deliver、capability、compose、draft 或 reconstruct。")
    return {"runtime_version": "1.9.1", "operation": operation, "result": result}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = find_project_root(Path(__file__).resolve())
    request = json.loads(args.input.read_text(encoding="utf-8"))
    response = execute(request, root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
