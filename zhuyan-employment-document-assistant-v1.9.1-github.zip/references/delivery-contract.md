# 成稿与文件交付契约 V1.9

`deliver`接收`dialogue`返回的完整`state`。交付前再次执行通用重构和完整正文自动审校；风险节点用于生成占位符、条件条款和审校提示，不再因信息缺失自动取消文件。

```json
{
  "operation": "deliver",
  "delivery": {
    "state": {"case_id": "C001", "selected_document_ids": ["R8"]},
    "formats": ["docx", "markdown", "json"]
  }
}
```

## 零文件门槛

只有尚未确定任何主文书、文件构建失败或产物校验失败时，`artifacts`为空。事实冲突、字段缺失、前置程序或证据未确认时，生成标注为待核验的文件并保留占位符；不得把冲突中的任一版本擅自写成确定事实。

## 文件字段

- `filename`：平台展示和保存时使用的安全文件名。
- `mime_type`：文件类型。
- `encoding`：DOCX为`base64`；Markdown和JSON为`utf-8`。
- `size_bytes`与`sha256`：平台落盘后校验文件完整性。
- `content`：编码后的文件内容。

平台只负责解码、保存和提供下载，不得修改正文、风险提示、证据状态或停止节点。公开端不得显示本地源文件路径、能力卡内部路径或完整对话记录。
